package io.cucumber.skeleton;

public class Belly {
    public void eat(int cukes) {

    }
}
