package test;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

public class TestCase extends TestBase{
    @Test
    public void testCase1(){
        TestPage page = new TestPage();
        WebElement element = page.getTableRowElement("Tapan","Button");
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].style.border='3px solid red'",element);
    }
}
