package test;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

public class TestCase extends TestBase{
    @Test
    public void testCase1(){
        TestPage page = new TestPage();
        System.out.println(page.getTableRow().size());
        WebElement element = page.getTableRowElement("Ankit");
        System.out.println(element);
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].style.border='3px solid red'",element);
    }
}
