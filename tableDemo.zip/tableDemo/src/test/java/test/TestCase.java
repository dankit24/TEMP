package test;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import java.security.Key;
import java.util.concurrent.TimeUnit;

public class TestCase extends TestBase{
    @Test
    public void testCase1() throws InterruptedException {
        TestPage page = new TestPage();
        /*Thread.sleep(TimeUnit.SECONDS.toMillis(30));
        String url = page.getURL().getText();
        System.out.println("url => "+url);
        JavascriptExecutor js = (JavascriptExecutor) driver;

        WebDriverWait wait = new WebDriverWait(driver,30);

        js.executeScript("window.open('"+url+"','_blank');");

        js.executeScript("arguments[0].style.border='3px solid red'",page.getDropdown());*/

        analyzeLogs();

    }
}
