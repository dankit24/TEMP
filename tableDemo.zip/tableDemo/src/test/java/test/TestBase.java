package test;

import io.github.bonigarcia.wdm.ChromeDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import java.text.SimpleDateFormat;
import java.util.Date;

public class TestBase {
    public static WebDriver driver;
    public EventFiringWebDriver e_driver;
    @BeforeSuite
    public void setUp(){
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy-hh-mm-ss");
        System.setProperty("current.date.time", dateFormat.format(new Date()));
        System.setProperty("app.root",""+System.getProperty("user.dir")+"");
        System.out.println(System.getProperty("app.root"));
        System.out.println(System.getProperty("current.date.time"));
        ChromeDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        e_driver = new EventFiringWebDriver(driver);
        WebEventListener eventListener = new WebEventListener();
        e_driver.register(eventListener);
        driver = e_driver;
        driver.manage().window().maximize();
        driver.get("file:///"+System.getProperty("user.dir")+"/src/test/resources/index.html");
    }
}
