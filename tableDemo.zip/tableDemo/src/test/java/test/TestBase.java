package test;

import io.github.bonigarcia.wdm.ChromeDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

public class TestBase {
    public static WebDriver driver;
    public EventFiringWebDriver e_driver;
    @BeforeSuite
    public void setUp(){
        System.setProperty("app.root",""+System.getProperty("user.dir")+"");
        ChromeDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        e_driver = new EventFiringWebDriver(driver);
        WebEventListener eventListener = new WebEventListener();
        e_driver.register(eventListener);
        driver = e_driver;
        driver.manage().window().maximize();
        driver.get("file:///"+System.getProperty("user.dir")+"/src/test/resources/index.html");
    }
}
