package test;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

public class TestListener extends TestBase implements ITestListener {
    private StringWriter stringWriter = new StringWriter();
    private String filePath = System.getProperty("user.dir")+"/screenshots/";
    @Override
    public void onTestStart(ITestResult result) {
        Log.startTestCase(result.getMethod().getMethodName());
    }

    @Override
    public void onTestSuccess(ITestResult result) {
        Log.endTestCase(result.getMethod().getMethodName());

    }

    @Override
    public void onTestFailure(ITestResult result) {
        result.getThrowable().printStackTrace(new PrintWriter(stringWriter));
        Log.error("Error on Testcase => " + result.getMethod().getMethodName() + "\n" +
                "Error => " + stringWriter.toString());

        String methodName = result.getMethod().getMethodName();

        takeScreenShot(methodName);

        Log.endTestCase(result.getMethod().getMethodName());
    }

    public void takeScreenShot(String methodName) {
        File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH.mm.ss");
        //The below method will save the screen shot in d drive with test method name
        try {
            FileUtils.copyFile(scrFile, new File(filePath+methodName+dateFormat.format(new Date())+".png"));
            System.out.println("***Placed screen shot in "+filePath+" ***");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    @Override
    public void onTestSkipped(ITestResult result) {
    }

    @Override
    public void onTestFailedButWithinSuccessPercentage(ITestResult result) {

    }

    @Override
    public void onTestFailedWithTimeout(ITestResult result) {

    }

    @Override
    public void onStart(ITestContext context) {

    }

    @Override
    public void onFinish(ITestContext context) {

    }
}
