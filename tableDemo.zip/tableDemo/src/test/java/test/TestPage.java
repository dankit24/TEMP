package test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.PageFactory;
import java.util.List;

public class TestPage extends TestBase{
    public TestPage() {
        PageFactory.initElements(driver, this);
    }
    @FindBys(@FindBy(xpath = "/html/body/table/tbody/tr"))
    List<WebElement> tableRow;

    public List<WebElement> getTableRow() {
        return tableRow;
    }

    public WebElement getTableRowElement(String name, String operator){
        WebElement element = null;
        for(WebElement tr: this.getTableRow()){
            if(tr.getText().contains(name)){
                List<WebElement> td = tr.findElements(By.tagName("td"));
                for (WebElement temp: td){
                    if(temp.getText().equals(operator)){
                        element = temp;
                        break;
                    }
                }
            }
        }
        return element;
    }

    public String getElementXPath(WebElement element){
        String source = element.toString();
        String[] temp = source.split("-> ");
        String[] temp2 = temp[1].split(": ");
        String locator = temp2[0];
        return temp2[1].substring(0,temp2[1].length()-1);
    }
}