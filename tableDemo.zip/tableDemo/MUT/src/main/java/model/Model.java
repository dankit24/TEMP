package model;

public class Model {
    public User getUser() {
        return readUserFromSource();
    }

    private User readUserFromSource() {
        return null;
    }
}
