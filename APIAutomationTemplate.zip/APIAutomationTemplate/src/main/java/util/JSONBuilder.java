package util;

import com.google.gson.JsonObject;

public class JSONBuilder {
    JsonObject jsonObj;

    public JsonObject getJsonObject() {
        return jsonObj;
    }

    public void setJsonObject(JsonObject jsonObj){
        this.jsonObj = jsonObj;
    }
}
