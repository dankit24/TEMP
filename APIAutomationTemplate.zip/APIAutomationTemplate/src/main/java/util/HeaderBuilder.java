package util;

import java.util.Map;

public class HeaderBuilder {
    Map<String,String> header;

    public Map<String, String> getHeader() {
        return header;
    }

    public void setHeader(Map<String, String> header) {
        this.header = header;
    }
}
