package base;

import com.google.gson.JsonObject;
import io.restassured.RestAssured;
import io.restassured.config.RestAssuredConfig;
import io.restassured.http.Headers;
import io.restassured.internal.RequestSpecificationImpl;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import util.HeaderBuilder;
import util.JSONBuilder;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class TestBase {

    public int RESPONSE_STATUS_CODE_200 = 200;
    public int RESPONSE_STATUS_CODE_500 = 500;
    public int RESPONSE_STATUS_CODE_400 = 400;
    public int RESPONSE_STATUS_CODE_401 = 401;
    public int RESPONSE_STATUS_CODE_201 = 201;

    public Properties prop;

    @BeforeSuite
    public void loadProperty(){
        FileInputStream fis = null;
        try {
            fis = new FileInputStream("C:\\Users\\Ankit\\Downloads\\APIAutomationTemplate\\src\\main\\java\\config\\config.properties");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        prop = new Properties();
        try {
            prop.load(fis);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @BeforeTest
    public void setURL(){
        HeaderBuilder headerBuilder = new HeaderBuilder();
        JSONBuilder jsonBuilder = new JSONBuilder();
        JsonObject jsonObject = new JsonObject();

    // 1. define the base url:
        RestAssured.baseURI = prop.getProperty("base_url");
    // 2. define the http request:
        RequestSpecification httpRequest = RestAssured.given();
    // 3. create a json object with all the fields:
        jsonObject.addProperty("name","Ankit Desai");
        jsonBuilder.setJsonObject(jsonObject);
    // 4. add header:
        httpRequest.headers(headerBuilder.getHeader());
    // 5. add the json payload to the body of the request:
        httpRequest.body(jsonBuilder.getJsonObject());
    // 6. post the request and get the response:
        Response response = httpRequest.post(prop.getProperty("post"));
    // 7. get the response body:
        String responseBody = response.getBody().asString();
        System.out.println("Response Body is: " + responseBody);
    // 8. get the status code and validate it:
        int statusCode = response.getStatusCode();
        System.out.println("the status code is: " + statusCode);
    // 9. get the headers:
        Headers headers = response.getHeaders();
        System.out.println(headers);

        String contentType = response.getHeader("Content-Type");
        System.out.println("the value of content-type header is: " + contentType);

        String contentLength = response.getHeader("Content-Length");
        System.out.println("the value of Content-Length header is: " + contentLength);

    }
}
