curl 'http://192.168.2.142:4444/lifecycle-manager?action=shutdown'
curl 'http://192.168.2.142:5555/lifecycle-manager/LifecycleServlet?action=shutdown'
lsof -ti TCP:5555 | xargs  kill


