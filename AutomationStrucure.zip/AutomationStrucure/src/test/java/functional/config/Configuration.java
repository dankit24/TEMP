package config;

public class Configuration {

    public static String DANMURPHYS_URL = "http://danmurphys.com.au/dm/home.jsp";
    public static final String DEFAULT_OS = "Mac OS X";
}
