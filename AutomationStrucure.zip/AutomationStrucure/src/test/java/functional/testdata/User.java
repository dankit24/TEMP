package testdata;

public class User {

}
