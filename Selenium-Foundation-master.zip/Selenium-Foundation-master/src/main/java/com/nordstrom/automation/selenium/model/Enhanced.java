package com.nordstrom.automation.selenium.model;

/**
 * This marker interface is added to dynamically created classes for future identification
 */
public interface Enhanced { }
