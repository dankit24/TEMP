package test;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.omg.PortableServer.THREAD_POLICY_ID;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

public class testbase {
    static WebDriver driver;

    @BeforeSuite
    public void setUp(){
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https:/google.com");
    }
    @Test
    public void test() throws InterruptedException {
        Thread.sleep(2000);

        util.runTimeInfo("error","error message");
        util.runTimeInfo("info","info message");
        util.runTimeInfo("warning","warning message");
    }
}
