package corporation;

import com.github.javafaker.Faker;
import org.junit.Test;
import base.*;

public class createCorporationJson {

    public Faker faker = new Faker();
    @Test
    public void createData(){

        String jsonData = "{\n" +
                "  \"data\": {\n" +
                "    \"corporationName\": \""+ FakerData.getCompanyName()+"\",\n" +
                "    \"corporationNotes\": \""+ FakerData.getNotes()+"\",\n" +
                "    \"legalTaxId\": \""+ FakerData.getId()+"\",\n" +
                "    \"legalTaxId_label\": \""+ FakerData.getId()+"\",\n" +
                "    \"corporationIndustryType\": \"PUBLIC\",\n" +
                "    \"corporationSectorType\": \"GOVERNMENT\",\n" +
                "    \"isAcctCharityOrg\": 0,\n" +
                "    \"address\": [\n" +
                "      {\n" +
                "        \"addressTypeCode\": \"MAILING\",\n" +
                "        \"line1\": \""+ FakerData.getAddressLine1()+"\",\n" +
                "        \"line2\": \""+ FakerData.getAddressLine2()+"\",\n" +
                "        \"line3\": \""+ FakerData.getAddressLine3()+"\",\n" +
                "        \"city\": \""+ FakerData.getAddressCity()+"\",\n" +
                "        \"state\": \""+ FakerData.getAddressState()+"\",\n" +
                "        \"country\": \""+ FakerData.getAddressCountry()+"\",\n" +
                "        \"area\": \""+ FakerData.getAddressCity()+"\",\n" +
                "        \"zipCode\": \""+ FakerData.getAddressZipCode()+"\",\n" +
                "        \"zipCodeLabel\": \"ZIP CODE\",\n" +
                "        \"phoneNumber\": \""+ FakerData.getPhoneNumber()+"\",\n" +
                "        \"phoneNumLabel\": \"PRIMARY\",\n" +
                "        \"phoneNumLabel2\": \"BILLING\"\n" +
                "      },\n" +
                "      {\n" +
                "        \"addressTypeCode\": \"BILLING\",\n" +
                "        \"line1\": \""+ FakerData.getAddressLine1()+"\",\n" +
                "        \"line2\": \""+ FakerData.getAddressLine2()+"\",\n" +
                "        \"line3\": \""+ FakerData.getAddressLine3()+"\",\n" +
                "        \"city\": \""+ FakerData.getAddressCity()+"\",\n" +
                "        \"state\": \""+ FakerData.getAddressState()+"\",\n" +
                "        \"country\": \""+ FakerData.getAddressCountry()+"\",\n" +
                "        \"area\": \""+ FakerData.getAddressCity()+"\",\n" +
                "        \"zipCode\": \""+ FakerData.getAddressZipCode()+"\",\n" +
                "        \"zipCodeLabel\": \"PIN CODE\",\n" +
                "        \"phoneNumber\": \""+ FakerData.getPhoneNumber()+"\",\n" +
                "        \"phoneNumLabel\": \"PRIMARY\",\n" +
                "        \"phoneNumLabel2\": \"MOBILE\"\n" +
                "      }\n" +
                "    ]\n" +
                "  }\n" +
                "}\n";
    }
}
