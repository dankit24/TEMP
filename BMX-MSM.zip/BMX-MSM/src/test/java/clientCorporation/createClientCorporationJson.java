package clientCorporation;

import com.github.javafaker.Faker;
import io.restassured.RestAssured;
import org.junit.Test;
import base.*;

public class createClientCorporationJson {
    public Faker faker = new Faker();
    public RestAssured restAssured = new RestAssured();

    @Test
    public void createData(){

        System.out.println("{\n" +
                "\t\"apiVersion\": \"1.0\",\n" +
                "\t\"data\": {\n" +
                "\t\t\"clientCompanyCategory\": \"CUSTOMER\",\n" +
                "\t\t\"clientCompanyName\": \""+ FakerData.getCompanyName()+"\",\n" +
                "\t\t\"clientCompanyNotes\": \""+ FakerData.getNotes()+"\",\n" +
                "\t\t\"legalTaxId\": \"111-22-3333\",\n" +
                "\t\t\"legalTaxId_label\": \"SSN\",\n" +
                "\t\t\"clientCompanyIndustryType\": \"PUBLIC\",\n" +
                "\t\t\"clientCompanySectorType\": \"OTHER\",\n" +
                "\t\t\"isAcctCharityOrg\": 0,\n" +
                "\t\t\"address\": [\n" +
                "\t\t\t{\n" +
                "\t\t\t\t\"addressTypeCode\": \"MAILING\",\n" +
                "\t\t\t\t\"line1\": \""+ FakerData.getAddressLine1()+"\",\n" +
                "\t\t\t\t\"line2\": \""+ FakerData.getAddressLine2()+"\",\n" +
                "\t\t\t\t\"line3\": \""+ FakerData.getAddressLine3()+"\",\n" +
                "\t\t\t\t\"city\": \""+ FakerData.getAddressCity()+"\",\n" +
                "\t\t\t\t\"state\": \""+ FakerData.getAddressState()+"\",\n" +
                "\t\t\t\t\"country\": \""+ FakerData.getAddressCountry()+"\",\n" +
                "\t\t\t\t\"area\": \""+ FakerData.getAddressCity()+"\",\n" +
                "\t\t\t\t\"zipCode\": \""+ FakerData.getAddressZipCode()+"\",\n" +
                "\t\t\t\t\"zipCodeLabel\": \"ZIP CODE\",\n" +
                "\t\t\t\t\"phoneNumber\": \""+ FakerData.getPhoneNumber()+"\",\n" +
                "\t\t\t\t\"phoneNumLabel\": \"PRIMARY\",\n" +
                "\t\t\t\t\"phoneNumLabel2\": \"BILLING\"\n" +
                "\t\t\t},\n" +
                "\t\t\t{\n" +
                "\t\t\t\t\"addressTypeCode\": \"BILLING\",\n" +
                "\t\t\t\t\"line1\": \""+ FakerData.getAddressLine1()+"\",\n" +
                "\t\t\t\t\"line2\": \""+ FakerData.getAddressLine2()+"\",\n" +
                "\t\t\t\t\"line3\": \""+ FakerData.getAddressLine3()+"\",\n" +
                "\t\t\t\t\"city\": \""+ FakerData.getAddressCity()+"\",\n" +
                "\t\t\t\t\"state\": \""+ FakerData.getAddressState()+"\",\n" +
                "\t\t\t\t\"country\": \""+ FakerData.getAddressCountry()+"\",\n" +
                "\t\t\t\t\"area\": \""+ FakerData.getAddressCity()+"\",\n" +
                "\t\t\t\t\"zipCode\": \""+ FakerData.getAddressZipCode()+"\",\n" +
                "\t\t\t\t\"zipCodeLabel\": \"ZIP CODE\",\n" +
                "\t\t\t\t\"phoneNumber\": \""+ FakerData.getPhoneNumber()+"\",\n" +
                "\t\t\t\t\"phoneNumLabel\": \"PRIMARY\",\n" +
                "\t\t\t\t\"phoneNumLabel2\": \"MOBILE\"\n" +
                "\t\t\t}\n" +
                "\t\t]\n" +
                "\t}\n" +
                "}");

    }
}
