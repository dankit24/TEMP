package base;

import com.github.javafaker.Faker;

public class fakerData {
    public static Faker faker = new Faker();

    public static String Id;
    public static String Title;
    public static String FirstName;
    public static String MiddleName;
    public static String LastName;
    public static String Nationality;
    public static String DOB;
    public static String Age;
    public static String Gender;
    public static String Location;
    public static String Position;
    public static String Website;
    public static String CompanyName;
    public static String AddressLine1;
    public static String AddressLine2;
    public static String AddressLine3;
    public static String AddressCity;
    public static String AddressState;
    public static String AddressCountry;
    public static String AddressZipCode;
    public static String PhoneNumber;
    public static String Notes;
    public static String EmailId;

    public static String getTitle() {
        Title = "Mr.";
        return Title;
    }

    public static String getNationality() {
        Nationality = faker.country().name();
        return Nationality;
    }

    public static String getDOB() {
        DOB = "12/08/1993";
        return DOB;
    }

    public static String getAge() {
        Age = "25";
        return Age;
    }

    public static String getGender() {
        Gender = "MALE";
        return Gender;
    }

    public static String getLocation() {
        Location = faker.address().cityName();
        return Location;
    }

    public static String getPosition() {
        Position = faker.name().title();
        return Position;
    }

    public static String getId() {
        Id = faker.idNumber().valid();
        return Id;
    }

    public static String getFirstName() {
        FirstName = faker.name().firstName();
        return FirstName;
    }

    public static String getMiddleName() {
        MiddleName = faker.name().firstName();
        return MiddleName;
    }

    public static String getLastName() {
        LastName = faker.name().lastName();
        return LastName;
    }

    public static String getWebsite() {
        Website = faker.internet().url();
        return Website;
    }

    public static String getCompanyName() {
        CompanyName = faker.company().name();
        return CompanyName;
    }

    public static String getAddressLine1() {
        AddressLine1 = faker.address().streetName();
        return AddressLine1;
    }

    public static String getAddressLine2() {
        AddressLine2 = faker.address().streetName();
        return AddressLine2;
    }

    public static String getAddressLine3() {
        AddressLine3 = faker.address().streetName();
        return AddressLine3;
    }

    public static String getAddressCity() {
        AddressCity = faker.address().city();
        return AddressCity;
    }

    public static String getAddressState() {
        AddressState = faker.address().state();
        return AddressState;
    }

    public static String getAddressCountry() {
        AddressCountry = faker.address().country();
        return AddressCountry;
    }

    public static String getAddressZipCode() {
        AddressZipCode = faker.address().zipCode();
        return AddressZipCode;
    }

    public static String getPhoneNumber() {
        PhoneNumber = faker.phoneNumber().subscriberNumber(10);
        return PhoneNumber;
    }

    public static String getNotes() {
        Notes = faker.lorem().sentence(8);
        return Notes;
    }

    public static String getEmailId() {
        EmailId = faker.internet().safeEmailAddress();
        return EmailId;
    }
}
