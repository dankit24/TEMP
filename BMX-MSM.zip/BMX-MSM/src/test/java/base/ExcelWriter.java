package base;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.*;

class Employee {
    private String CompanyID;
    private String CompanyName;
    private String ContractID;
    private String PackageID;
    private String PackageName;
    private String EmployeeID;
    private String NationalID;
    private String Nationality;
    private String Passportno;
    private String Title;
    private String LastName;
    private String FirstName;
    private String MiddleName;
    private String DOBDDMMYYYY;
    private String DOBBuddhist;
    private String Age;
    private String Gender;
    private String Location;
    private String Position;
    private String Email;
    private String Phone;
    private String LineID;


public Employee(
        String CompanyID,
        String CompanyName,
        String ContractID,
        String PackageID,
        String PackageName,
        String EmployeeID,
        String NationalID,
        String Nationality,
        String Passportno,
        String Title,
        String FirstName,
        String MiddleName,
        String LastName,
        String DOBDDMMYYYY,
        String DOBBuddhist,
        String Age,
        String Gender,
        String Location,
        String Position,
        String Email,
        String Phone,
        String LineID)
{
    this.CompanyID = CompanyID;
    this.CompanyName = CompanyName;
    this.ContractID = ContractID;
    this.PackageID = PackageID;
    this.PackageName = PackageName;
    this.EmployeeID = EmployeeID;
    this.NationalID = NationalID;
    this.Nationality = Nationality;
    this.Passportno = Passportno;
    this.Title = Title;
    this.LastName = LastName;
    this.FirstName = FirstName;
    this.MiddleName = MiddleName;
    this.DOBDDMMYYYY = DOBDDMMYYYY;
    this.DOBBuddhist = DOBBuddhist;
    this.Age = Age;
    this.Gender = Gender;
    this.Location = Location;
    this.Position = Position;
    this.Email = Email;
    this.Phone = Phone;
    this.LineID = LineID;
}

    public String getCompanyID() {
        return CompanyID;
    }

    public String getCompanyName() {
        return CompanyName;
    }

    public String getContractID() {
        return ContractID;
    }

    public String getPackageID() {
        return PackageID;
    }

    public String getPackageName() {
        return PackageName;
    }

    public String getEmployeeID() {
        return EmployeeID;
    }

    public String getNationalID() {
        return NationalID;
    }

    public String getNationality() {
        return Nationality;
    }

    public String getPassportno() {
        return Passportno;
    }

    public String getTitle() {
        return Title;
    }

    public String getLastName() {
        return LastName;
    }

    public String getFirstName() {
        return FirstName;
    }

    public String getMiddleName() {
        return MiddleName;
    }

    public String getDOBDDMMYYYY() {
        return DOBDDMMYYYY;
    }

    public String getDOBBuddhist() {
        return DOBBuddhist;
    }

    public String getAge() {
        return Age;
    }

    public String getGender() {
        return Gender;
    }

    public String getLocation() {
        return Location;
    }

    public String getPosition() {
        return Position;
    }

    public String getEmail() {
        return Email;
    }

    public String getPhone() {
        return Phone;
    }

    public String getLineID() {
        return LineID;
    }

    // Getters and Setters (Omitted for brevity)
}

    public class ExcelWriter {


        private static String columns[] = {
                "Company ID",
                "Company Name",
                "Contract ID",
                "Package ID",
                "Package Name",
                "Employee ID",
                "National ID",
                "Nationality",
                "Passport no",
                "Title",
                "Last Name",
                "First Name",
                "Middle Name",
                "DOB (DD/MM/YYYY)",
                "DOB (Buddhist)",
                "Age",
                "Gender",
                "Location",
                "Position",
                "Email",
                "Phone",
                "Line ID"
        };

        private static List<Employee> employees =  new ArrayList<>();

        // Initializing employees data to insert into the excel file


        static {


            Scanner input = new Scanner(System.in);
            System.out.println("enter number of employees: ");
            int noOfEmployee = input.nextInt();

            System.out.println("enter company id: ");
            String CompanyID = input.next();

            System.out.println("enter company name: ");
            String CompanyName = input.next();

            System.out.println("enter contract id: ");
            String ContractID = input.next();

            System.out.println("enter package id: ");
            String PackageID = input.next();

            System.out.println("enter package name: ");
            String PackageName = input.next();

            System.out.println("creating "+noOfEmployee+" employees.");
            System.out.println("creating employees");

            for (int i = 0; i < noOfEmployee; i++) {
                employees.add(new Employee(
                        CompanyID,
                        CompanyName,
                        ContractID,
                        PackageID,
                        PackageName,
                        FakerData.getId(),
                        FakerData.getId(),
                        FakerData.getNationality(),
                        FakerData.getId(),
                        FakerData.getTitle(),
                        FakerData.getLastName(),
                        FakerData.getFirstName(),
                        FakerData.getMiddleName(),
                        FakerData.getDOB(),
                        FakerData.getDOB(),
                        FakerData.getAge(),
                        FakerData.getGender(),
                        FakerData.getLocation(),
                        FakerData.getPosition(),
                        FakerData.getEmailId(),
                        FakerData.getPhoneNumber(),
                        FakerData.getId()));
            }
            System.out.println("Employee created Successfully");
        }

        public static void main(String[] args) throws IOException, InvalidFormatException {


            // Create a Workbook
            Workbook workbook = new XSSFWorkbook(); // new HSSFWorkbook() for generating `.xlsx` file

            // Create a Sheet
            Sheet sheet = workbook.createSheet("Employee");

            // Create a Font for styling header cells
            Font headerFont = workbook.createFont();
            headerFont.setFontName("Calibri");
            headerFont.setFontHeightInPoints((short) 11);

            // Create a CellStyle with the font
            CellStyle headerCellStyle = workbook.createCellStyle();
            headerCellStyle.setFont(headerFont);

            // Create a Row
            Row headerRow = sheet.createRow(0);

            // Create cells
            for(int i = 0; i < columns.length; i++) {
                Cell cell = headerRow.createCell(i);
                cell.setCellValue(columns[i]);
                cell.setCellStyle(headerCellStyle);
            }

            // Create Other rows and cells with employees data
            int rowNum = 1;
            System.out.println(employees.size());


            System.out.println("writing data in to excel file");
                for (Employee employee : employees) {

                    Row row = sheet.createRow(rowNum++);

                    row.createCell(0).setCellValue(employee.getCompanyID());
                    row.createCell(1).setCellValue(employee.getCompanyName());
                    row.createCell(2).setCellValue(employee.getContractID());
                    row.createCell(3).setCellValue(employee.getPackageID());
                    row.createCell(4).setCellValue(employee.getPackageName());
                    row.createCell(5).setCellValue(employee.getEmployeeID());
                    row.createCell(6).setCellValue(employee.getNationalID());
                    row.createCell(7).setCellValue(employee.getNationality());
                    row.createCell(8).setCellValue(employee.getPassportno());
                    row.createCell(9).setCellValue(employee.getTitle());
                    row.createCell(10).setCellValue(employee.getLastName());
                    row.createCell(11).setCellValue(employee.getFirstName());
                    row.createCell(12).setCellValue(employee.getMiddleName());
                    row.createCell(13).setCellValue(employee.getDOBDDMMYYYY());
                    row.createCell(14).setCellValue(employee.getDOBBuddhist());
                    row.createCell(15).setCellValue(employee.getAge());
                    row.createCell(16).setCellValue(employee.getGender());
                    row.createCell(17).setCellValue(employee.getLocation());
                    row.createCell(18).setCellValue(employee.getPosition());
                    row.createCell(19).setCellValue(employee.getEmail());
                    row.createCell(20).setCellValue(employee.getPhone());
                    row.createCell(21).setCellValue(employee.getLineID());
                }

            // Resize all columns to fit the content size
            for(int i = 0; i < columns.length; i++) {
                sheet.autoSizeColumn(i);
            }

            // Write the output to a file
            FileOutputStream fileOut = new FileOutputStream("/home/qa/Desktop/poi-generated-file.xlsx");
            workbook.write(fileOut);
            fileOut.close();
            System.out.println("file writing complete");

            // Closing the workbook
            workbook.close();
        }
    }
