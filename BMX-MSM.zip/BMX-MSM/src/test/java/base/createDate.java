package base;

import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class createDate extends FakerData {
    @Test
    public void  createDate(){
        System.out.println(FakerData.getCompanyName());
        System.out.println(FakerData.getNotes());
        System.out.println(FakerData.getEmailId());
        System.out.println(FakerData.getPhoneNumber());
        System.out.println(FakerData.getAddressLine1());
        System.out.println(FakerData.getAddressLine2());
        System.out.println(FakerData.getAddressLine3());
        System.out.println(FakerData.getAddressCity());
        System.out.println(FakerData.getAddressState());
        System.out.println(FakerData.getAddressCountry());
        System.out.println(FakerData.getAddressZipCode());
        System.out.println(FakerData.getId());

    }
}
