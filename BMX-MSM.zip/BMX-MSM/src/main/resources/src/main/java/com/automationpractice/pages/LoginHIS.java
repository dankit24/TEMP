package com.automationpractice.pages;

import com.automationpractice.base.BaseClass;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

public class LoginHIS extends BaseClass {

    @FindBy(xpath = "//input[@autocomplete='username']")
    WebElement userName;

    @FindBy(xpath = "//input[@autocomplete='current-password']")
    WebElement password;

    @FindBy(xpath = "//span[text()='Login']")
    WebElement loginBtn;

    public LoginHIS() throws IOException {
        PageFactory.initElements(driver,this);
    }

    public boolean isPageLoaded(){
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
        return userName.isDisplayed();
    }

    public SignInPage loginHIS(){
        userName.sendKeys(prop.getProperty("userName"));
        password.sendKeys(prop.getProperty("password"));
        loginBtn.click();
        return new SignInPage();
    }
}
