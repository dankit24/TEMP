package com.automationpractice.scripts;

import com.automationpractice.base.BaseClass;
import com.automationpractice.pages.LoginHIS;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.io.IOException;

public class LoginHISTest extends BaseClass {

    LoginHISTest loginHISTest;



    public LoginHISTest() throws IOException {
        super();
    }

    @BeforeMethod
    public void setUp() throws IOException {
        init();
        loginHISTest = new LoginHISTest();
    }

    @Test
    public void lunchHIS() throws IOException {
        LoginHIS login = new LoginHIS();
        login.isPageLoaded();
        login.loginHIS();
    }

    @AfterMethod
    public void cleanUp() {
        driver.manage().deleteAllCookies();
        //driver.quit();
    }

}
