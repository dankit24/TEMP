package testdata;

import java.util.HashMap;

public class DropDownEnum {
    public final HashMap<String, String> BloodGroup= new HashMap<>();

    public void test(){
        BloodGroup.put("A_Positive","A ve+");
    }
    public enum BloodGroup {
        A_POSITIVE("A ve+"),B_POSITIVE("B ve+"),AB_POSITIVE("AB ve+"),O_POSITIVE("O ve+"),A_NEGATIVE("A ve-"),B_NEGATIVE("B ve-"),AB_NEGATIVE("AB ve-"),O_NEGATIVE("O ve-"),UNKNOWN("Unknown");
        public final String value;
        BloodGroup(String value) { this.value = value; }
    }

    public enum Initials {
        MR("Mr."),MS("Ms."),MRS("Mrs."),UNDEFINED("undefined");
        public final String value;
        Initials(String value) { this.value = value; }
    }

    public enum Gender {
        MALE("Male"),FEMALE("Female"),UNKNOWN("Unknown"),OTHER("Other");
        public final String value;
        Gender(String value) { this.value = value; }
    }

    public enum Religion {
        BUDDHIST("Buddhist"), CHRISTIAN("Christian"), HINDU("Hindu"), MUSLIM("Muslim"), UNKNOWN("Unknown"), OTHER("Other");
        public final String value;
        Religion(String value) { this.value = value; }
    }

    public enum Nationality {
        THAILAND("Thailand"), OTHER("Other");
        public final String value;
        Nationality(String value) { this.value = value; }
    }

    public enum EvidenceType {
        IDENTIFICATION("Identification"), NATIONAL_ID("National ID"), PASSPORT("Passport"), SOCIAL_SECURITY_NO("Social security No"), DRIVING_LICENSE("Driving License");
        public final String value;
        EvidenceType(String value) { this.value = value; }
    }

    public enum PaymentType {
        SOCIAL_SECURITY("Social Security"), INSURANCE("Insurance"), COMPANY_CONTRACT("Company Contract");
        public final String value;
        PaymentType(String value) { this.value = value; }
    }

    public enum PatientAppointmentStatus {
        SCHEDULED("Scheduled"), CANCELLED("Cancelled"), RE_SCHEDULED("Re-Scheduled"), NO_SHOW("No Show"), CHECKED_IN("Checked In");
        public final String value;
        PatientAppointmentStatus(String value) { this.value = value; }
    }

    public enum SeverityStatus {
        NORMAL("Normal"), URGENT("Urgent");
        public final String value;
        SeverityStatus(String value) { this.value = value; }
    }

    public enum RequestStatus {
        ACCEPTED("Accepted"),DECLINED("Declined");
        public final String value;
        RequestStatus(String value) { this.value = value; }
    }

    public enum PaymentStatus {
        COMPLETED("Completed"), INCOMPLETE("Incomplete");
        public final String value;
        PaymentStatus(String value) { this.value = value; }
    }

    public enum BedCondition {
        WORKING("Working"), UNDER_MAINTENANCE("Under Maintenance");
        public final String value;
        BedCondition(String value) { this.value = value; }
    }

    public enum OccupancyStatus {
        VACANT("Vacant"), OCCUPIED("Occupied");
        public final String value;
        OccupancyStatus(String value) { this.value = value; }
    }


}



