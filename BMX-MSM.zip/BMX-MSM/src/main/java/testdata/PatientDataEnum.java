package testdata;

public class PatientDataEnum {

    public enum dataType{
        BASIC_INFO("basic info"),
        MEDICAL_HISTORY_INFO("medical history info"),
        IDENTIFICATION_INFO("identification info"),
        PAYMENT_PLAN_INFO("payment plan info");
        public final String value;
        dataType(String value){ this.value = value; }
    }

    public enum basicInfo {
        PROFILE_PICTURE("profilePicture"),
        INITIALS("initials"),
        LAST_NAME("lastname"),
        FIRST_NAME("firstname"),
        MIDDLE_NAME("middlename"),
        DOB("dob"),
        GENDER("gender"),
        BLOOD_GROUP("bloodgroup"),
        RELIGION("religion"),
        OCCUPATION("occupation"),
        NATIONALITY("nationality"),
        EMAIL("email"),
        PHONE("phone"),
        ADDRESS_LINE1("addressline1"),
        ADDRESS_LINE2("addressline2"),
        ADDRESS_LINE3("addressline3"),
        CITY("city"),
        STATE("state"),
        COUNTRY("country"),
        POSTAL_CODE("postalcode"),
        KIN_NAME("kinname"),
        KIN_RELATION("kinrelation"),
        KIN_PHONE("kinphone");

        public final String value;
        basicInfo(String value) { this.value = value; }
    }
    public enum medicalHistoryInfo{
        DISEASE_NAME("diseasename"),
        DISEASE_NOTE("diseasenote"),
        PROCEDURE_NAME("procedurename"),
        PROCEDURE_MONTH_YEAR("proceduremonthyear"),
        MEDICATION_NAME("medicationname"),
        ALLERGY_NAME("allergyname"),
        ADDICTION_NAME("addictionname"),
        FATHER_DISEASE_NAME("fatherdiseasename"),
        MOTHER_DISEASE_NAME("motherdiseasename"),
        SIBLING_DISEASE_NAME("siblingdiseasename"),
        START_DATE("startdate"),
        END_DATE("enddate");

        public final String value;
        medicalHistoryInfo(String value){this.value=value;}
    }
    public enum identificationInfo{
        EVIDENCE_TYPE("evidencetype"),
        EVIDENCE_ID("nationalid"),
        EVIDENCE_NOTE("evidencenote"),
        EVIDENCE_DOCUMENT("evidencedocument");

        public final String value;
        identificationInfo(String value){this.value=value;}
    }

    public enum paymentPlanInfo{
        PAYMENT_TYPE("paymenttype"),
        SOCIAL_SECURITY_NO("socialsecurityno"),
        INSURANCE_COMPANY_NAME("insurancecompanyname"),
        PLAN_ID("planid"),
        PLAN_NAME("planname"),
        COMPANY_NAME("companyname"),
        COMPANY_ID("companyid"),
        CONTRACT_ID("contractid"),
        EMPLOYEE_ID("employeeid"),
        EMPLOYEE_ROLE("employeerole"),
        EMPLOYEE_DEPARTMENT("employeedepartment"),
        START_DATE("startdate"),
        END_DATE("enddate"),
        PAYMENT_PLAN_NOTE("paymentplannote"),
        PAYMENT_TYPE_DOCUMENT("paymenttypedocument");

    public final String value;
    paymentPlanInfo(String value){this.value=value;}
    }
}
