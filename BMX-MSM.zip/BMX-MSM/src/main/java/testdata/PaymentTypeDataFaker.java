package testdata;

import com.github.javafaker.Faker;

import java.util.concurrent.TimeUnit;

public class PaymentTypeDataFaker {
    private static Faker faker = new Faker();
    private static String paymentType;
    private static String socialSecurityNo;
    private static String insuranceCompanyName;
    private static String planId;
    private static String planName;
    private static String companyName;
    private static String companyId;
    private static String contractId;
    private static String employeeId;
    private static String employeeRole;
    private static String employeeDept;
    private static String startDate;
    private static String endDate;
    private static String paymentPlanNote;
    private static String paymentDocument;

    public static String getPaymentType() {
        paymentType = String.valueOf(faker.random().nextInt(1,3));
        switch (paymentType){
            case "1":
                paymentType="Social Security";
                break;
            case "2":
                paymentType="Insurance";
                break;
            case "3":
                paymentType="Company Contract";
                break;
            default:
                paymentType="invalid";
                break;
        }
        return paymentType;
    }

    public static String getSocialSecurityNo() {
        socialSecurityNo = "SS"+faker.number().numberBetween(5000,10000);
        return socialSecurityNo;
    }

    public static String getInsuranceCompanyName() {
        insuranceCompanyName = faker.company().name();
        return insuranceCompanyName;
    }

    public static String getPlanId() {
        planId = "PID"+faker.number().numberBetween(1000,9999);
        return planId;
    }

    public static String getPlanName() {
        planName = "Plan "+faker.lorem().fixedString(5);
        return planName;
    }

    public static String getCompanyName() {
        companyName = faker.company().name();
        return companyName;
    }

    public static String getCompanyId() {
        companyId = "CID"+faker.number().numberBetween(1000,5000);
        return companyId;
    }

    public static String getContractId() {
        contractId = "CONID"+faker.number().numberBetween(1000,5000);
        return contractId;
    }

    public static String getEmployeeId() {
        employeeId = "EID"+faker.number().numberBetween(1000,5000);
        return employeeId;
    }

    public static String getEmployeeRole() {
        employeeRole = faker.job().position();
        return employeeRole;
    }

    public static String getEmployeeDept() {
        employeeDept = faker.commerce().department();
        return employeeDept;
    }

    public static String getStartDate() {
        startDate = String.valueOf(faker.date().past(1000, TimeUnit.DAYS));
        return startDate;
    }

    public static String getEndDate() {
        startDate = String.valueOf(faker.date().future(1000, TimeUnit.DAYS));
        return endDate;
    }

    public static String getPaymentPlanNote() {
        paymentPlanNote = faker.lorem().paragraph(5);
        return paymentPlanNote;
    }

    public static String getPaymentDocument() {
        paymentDocument = System.getProperty("user.dir")+"/src/main/resources/Profile Pic/certi/certi"+faker.random().nextInt(1,8)+".png";
        return paymentDocument;
    }
}
