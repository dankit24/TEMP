package testdata;

import com.github.javafaker.Faker;

import java.time.ZoneOffset;
import java.time.ZonedDateTime;

public class BasicInfoDataFaker {
    public static Faker faker = new Faker();

    private static String Id;
    private static String Title;
    private static String FirstName;
    private static String MiddleName;
    private static String LastName;
    private static String Nationality;
    private static String DOB;
    private static String Age;
    private static String Gender;
    private static String Location;
    private static String Position;
    private static String Website;
    private static String CompanyName;
    private static String AddressLine1;
    private static String AddressLine2;
    private static String AddressLine3;
    private static String AddressCity;
    private static String AddressState;
    private static String AddressCountry;
    private static String AddressZipCode;
    private static String PhoneNumber;
    private static String Notes;
    private static String EmailId;
    private static String kinFullName;
    private static String kinRelation;
    private static String bloodGroup;
    private static String religion;
    private static String avatar;
    private static String occupation;

    public static String getTitle() {
        if(faker.random().nextInt(1,3)==1){
            Title = "Ms.";
        }
        else if(faker.random().nextInt(1,3)==2){
            Title = "Mrs.";
        }
        else {
            Title = "Mr.";
        }
        return Title;
    }

    public static String getOccupation(){
        occupation = faker.company().profession();
        return occupation;
    }
    public static String getBloodGroup(){
        switch (faker.name().bloodGroup()){
            case "A+":
                bloodGroup = "A +ve";
            break;
            case "A-":
                bloodGroup = "A -ve";
                break;
            case "B+":
                bloodGroup = "B +ve";
                break;
            case "B-":
                bloodGroup = "B -ve";
                break;
            case "AB+":
                bloodGroup = "AB +ve";
                break;
            case "AB-":
                bloodGroup = "AB -ve";
                break;
            case "O+":
                bloodGroup = "O +ve";
                break;
            case "O-":
                bloodGroup = "O -ve";
                break;
            default:
                bloodGroup = "Unknown";
        }
        return bloodGroup;
    }

    public static String getAvatar(){
        avatar = System.getProperty("user.dir")+"/src/main/resources/Profile Pic/avatar/avatar"+faker.random().nextInt(1,58)+".png";
        return avatar;
    }

    public static String getReligion(){
        religion = String.valueOf(faker.random().nextInt(51,56));
        switch (religion){
            case "51":
                religion = "Unknown";
                break;
            case "52":
                religion = "Buddhist";
                break;
            case "53":
                religion = "Christian";
                break;
            case "54":
                religion = "Hindu";
                break;
            case "55":
                religion = "Muslim";
                break;
            case "56":
                religion = "Other";
                break;
            default:
                religion = "invalid";
                break;
        }
        return religion;
    }

    public static String getNationality() {
        Nationality = String.valueOf(faker.random().nextInt(307,308));
        switch (Nationality){
            case "307":
                Nationality = "Thai";
                break;
            case "308":
                Nationality = "Other";
                break;
            default:
                Nationality="invalid";
                break;
        }
        return Nationality;
    }

    public static String getDOB() {
        ZonedDateTime zonedDateTime = ZonedDateTime.of(faker.number().numberBetween(1989,2018),faker.number().numberBetween(1,12),faker.number().numberBetween(1,28),18,30,00,000, ZoneOffset.UTC);
        DOB = String.valueOf(zonedDateTime);
        return DOB;
    }

    public static String getAge() {
        Age = String.valueOf(faker.random().nextInt(18,60));
        return Age;
    }

    public static String getGender() {
        Gender = String.valueOf(faker.random().nextInt(58,61));
        switch (Gender){
            case "58":
                Gender = "Male";
                break;
            case "59":
                Gender = "Female";
                break;
            case "60":
                Gender = "Other";
                break;
            case "61":
                Gender = "Unknown";
                break;
            default:
                Gender = "invalid";
                break;
        }
        return Gender;
    }

    public static String getLocation() {
        Location = faker.address().cityName();
        return Location;
    }

    public static String getPosition() {
        Position = faker.name().title();
        return Position;
    }

    public static String getId() {
        Id = faker.idNumber().valid();
        return Id;
    }

    public static String getFirstName() {
        FirstName = faker.name().firstName();
        return FirstName;
    }

    public static String getMiddleName() {
        MiddleName = faker.name().firstName();
        return MiddleName;
    }

    public static String getLastName() {
        LastName = faker.name().lastName();
        return LastName;
    }

    public static String getCompanyName() {
        CompanyName = faker.company().name();
        return CompanyName;
    }

    public static String getAddressLine1() {
        AddressLine1 = faker.address().streetName();
        return AddressLine1;
    }

    public static String getAddressLine2() {
        AddressLine2 = faker.address().streetName();
        return AddressLine2;
    }

    public static String getAddressLine3() {
        AddressLine3 = faker.address().streetName();
        return AddressLine3;
    }

    public static String getAddressCity() {
        AddressCity = faker.address().city();
        return AddressCity;
    }

    public static String getAddressState() {
        AddressState = faker.address().state();
        return AddressState;
    }

    public static String getAddressCountry() {
        AddressCountry = faker.address().country();
        return AddressCountry;
    }

    public static String getAddressZipCode() {
        AddressZipCode = faker.address().zipCode();
        return AddressZipCode;
    }

    public static String getPhoneNumber() {
        PhoneNumber = faker.phoneNumber().subscriberNumber(10);
        return PhoneNumber;
    }

    public static String getNotes() {
        Notes = faker.lorem().sentence(8);
        return Notes;
    }

    public static String getEmailId() {
        EmailId = faker.internet().safeEmailAddress();
        return EmailId;
    }

    public static String getWebsite() {
        Website = faker.internet().url();
        return Website;
    }

    public static String getKinFullName() {
        kinFullName = faker.name().fullName();
        return kinFullName;
    }

    public static String getKinRelation() {
        kinRelation = faker.relationships().any();
        return kinRelation;
    }
}
