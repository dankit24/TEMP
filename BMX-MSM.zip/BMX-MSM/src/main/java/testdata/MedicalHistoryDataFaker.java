package testdata;

import com.github.javafaker.Faker;

import java.util.concurrent.TimeUnit;

public class MedicalHistoryDataFaker {
    public static Faker faker = new Faker();

    private static String currentDate;
    private static String diseaseName;
    private static String diseaseNote;
    private static String procedureName;
    private static String procedureMonthYear;
    private static String medicationName;
    private static String allergyName;
    private static String addictionName;
    private static String fatherDiseaseName;
    private static String motherDiseaseName;
    private static String siblingDiseaseName;
    private static String startDate;
    private static String endDate;


    public static String getDiseaseName() {
        diseaseName = faker.medical().diseaseName();
        return diseaseName;
    }

    public static String getDiseaseNote() {
        diseaseNote = faker.medical().symptoms();
        return diseaseNote;
    }

    public static String getProcedureName() {
        procedureName = faker.medical().medicineName();
        return procedureName;
    }

    public static String getProcedureMonthYear() {

        procedureMonthYear = String.valueOf(faker.date().past(1000, TimeUnit.DAYS));
        return procedureMonthYear;
    }

    public static String getMedicationName() {
        medicationName = faker.medical().medicineName();
        return medicationName;
    }

    public static String getAllergyName() {
        allergyName = faker.medical().diseaseName();
        return allergyName;
    }

    public static String getAddictionName() {
        addictionName = faker.medical().diseaseName();
        return addictionName;
    }

    public static String getFatherDiseaseName() {
        fatherDiseaseName = faker.medical().diseaseName();
        return fatherDiseaseName;
    }

    public static String getMotherDiseaseName() {
        motherDiseaseName = faker.medical().diseaseName();
        return motherDiseaseName;
    }

    public static String getSiblingDiseaseName() {
        siblingDiseaseName = faker.medical().diseaseName();
        return siblingDiseaseName;
    }

    public static String getStartDate() {
        startDate = String.valueOf(faker.date().past(2000,1000,TimeUnit.DAYS));
        return startDate;
    }

    public static String getEndDate() {
        if(faker.random().nextBoolean()){
            endDate = currentDate;
        }
        else {
            endDate = String.valueOf(faker.date().past(1000, TimeUnit.DAYS));
        }
        return endDate;
    }
}
