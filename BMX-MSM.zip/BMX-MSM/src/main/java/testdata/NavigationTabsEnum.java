package testdata;

public class NavigationTabsEnum {

    public enum NavigationTabs {
        REGISTRATION("Registration"), PAYMENT_TYPE("Payment Type"), PATIENT_VISIT("Patient Visit"),ADT_MANAGEMENT("ADT Management"), BED_MANAGEMENT("Bed Management");
        public final String value;
        NavigationTabs(String value) { this.value = value; }
    }

    public enum RegistrationTabs {
        DASHBOARD("Dashboard"), PATIENT("Patient"), PATIENT_VERIFICATION("Patient Verification");
        public final String value;
        RegistrationTabs(String value) { this.value = value; }
    }

    public enum PaymentTypeTabs {
        DASHBOARD("Dashboard"), PATIENT_PLAN("Payment Plan"), VALIDATE_PAYMENT("Validate Payment"), VALIDATE_COVERAGE("Validate Coverage"), PAYMENT_PRIORITY("Payment Priority");
        public final String value;
        PaymentTypeTabs(String value) { this.value = value; }
    }

    public enum PatientVisitTabs {
        DASHBOARD("Dashboard"), PATIENT_APPOINTMENT("Patient Appointment"), TRIAGE("Triage");
        public final String value;
        PatientVisitTabs(String value) { this.value = value; }
    }

    public enum ADTManagementTabs {
        DASHBOARD("Dashboard"), ADMIT_TRANSFER_REQUEST("Admit Transfer Request"), PATIENTVERIFICATION("Patient Verification"), PAYMENT_PLAN("Payment Plan"), BED_OCCUPANCY("Bed Occupancy"), BOOK_BED("Book Bed"), DISCHARGE_PATIENT("Discharge Patient");
        public final String value;
        ADTManagementTabs(String value) { this.value = value; }
    }

    public enum BedManagementTabs {
        DASHBOARD("Dashboard"), HOSPITAL_BED("Hospital Bed"), ROOM_TYPE("Room Type"), BED_PIPELINE("Bed Pipeline");
        public final String value;
        BedManagementTabs(String value) { this.value = value; }
    }


}




