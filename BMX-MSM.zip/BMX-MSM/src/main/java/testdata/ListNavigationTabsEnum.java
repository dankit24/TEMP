package testdata;

public class ListNavigationTabsEnum {

    public enum PatientList{
        ALL("All"), TODAY("Today's App."), NEW_REG("New Reg."), PREV_REG("Previously Reg.");
        public final String value;
        PatientList(String value){ this.value=value; }
    }
    public enum VerificationList{
        PENDING("Pending Requests"), COMPLETED("Completed Requests");
        public final String value;
        VerificationList(String value){ this.value=value; }
    }
    public enum PaymentList{
        PENDING("Pending Requests"), COMPLETED("Completed Requests");
        public final String value;
        PaymentList(String value){ this.value=value; }
    }
    public enum PatientAptList{
        TODAY("Today's App."), ALL("All App.");
        public final String value;
        PatientAptList(String value){ this.value=value; }
    }
    public enum TriageList{
        PENDING("Pending Requests"), COMPLETED("Completed Requests");
        public final String value;
        TriageList(String value){ this.value=value; }
    }
    public enum ADTRequestList{
        PENDING_ADMIT("Pending Admit Requests"), PENDING_BED("Pending Bed Transfers"), COMPLETED("Completed Requests");
        public final String value;
        ADTRequestList(String value){ this.value=value; }
    }
    public enum ADTPaymentList{
        PENDING_ADMIT("Pending Admit Requests"), COMPLETED("Completed Admit Requests");
        public final String value;
        ADTPaymentList(String value){ this.value=value; }
    }
    public enum BookBedList{
        PENDING_ADMIT("Pending Admit Requests"), PENDING_BED("Pending Bed Transfers"), COMPLETED("Completed Requests");
        public final String value;
        BookBedList(String value){ this.value=value; }
    }


}
