package testdata;

import com.github.javafaker.Faker;

public class IdentificationDataFaker {
    private static Faker faker = new Faker();
    private static String evidenceType;
    private static String evidenceId;
    private static String evidenceNote;
    private static String evidenceDocument;

    public static String getEvidenceType() {
        evidenceType = String.valueOf(faker.random().nextInt(1,5));
        switch (evidenceType){
            case "1":
                evidenceType = "Identification";
                break;
            case "2":
                evidenceType = "National ID";
                break;
            case "3":
                evidenceType = "Passport";
                break;
            case "4":
                evidenceType = "Social security No";
                break;
            case "5":
                evidenceType = "Driving License";
                break;
            default:
                evidenceType = "invalid";
                break;
        }
        return evidenceType;
    }

    public static String getEvidenceId() {
        evidenceId = faker.idNumber().valid();
        return evidenceId;
    }

    public static String getEvidenceNote() {
        evidenceNote = faker.lorem().paragraph(5);
        return evidenceNote;
    }

    public static String getEvidenceDocument() {
        evidenceDocument = System.getProperty("user.dir")+"/src/main/resources/Profile Pic/id/id"+faker.random().nextInt(1,3)+".png";
        return evidenceDocument;
    }
}
