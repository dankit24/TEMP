package base;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class Employee {
/*            private String profilePicture;
            private String initials;
            private String lastname;
            private String firstname;
            private String middlename;
            private String dob;
            private String gender;
            private String bloodgroup;
            private String religion;
            private String occupation;
            private String nationality;
            private String email;
            private String phone;
            private String addressline1;
            private String addressline2;
            private String addressline3;
            private String city;
            private String state;
            private String country;
            private String postalcode;
            private String kinname;
            private String kinrelation;
            private String kinphone;

public Employee(
        String profilePicture,
        String initials,
        String lastname,
        String firstname,
        String middlename,
        String dob,
        String gender,
        String bloodgroup,
        String religion,
        String occupation,
        String nationalitity,
        String email,
        String phone,
        String addressline1,
        String addressline2,
        String addressline3,
        String city,
        String state,
        String country,
        String postalcode,
        String kinname,
        String kinrelation,
        String kinphone)
{
    this.profilePicture = profilePicture;
    this.initials = initials;
    this.lastname = lastname;
    this.firstname = firstname;
    this.middlename = middlename;
    this.dob = dob;
    this.gender = gender;
    this.bloodgroup = bloodgroup;
    this.religion = religion;
    this.occupation = occupation;
    this.nationality = nationalitity;
    this.email = email;
    this.phone = phone;
    this.addressline1 = addressline1;
    this.addressline2 = addressline2;
    this.addressline3 = addressline3;
    this.city = city;
    this.state = state;
    this.country = country;
    this.postalcode = postalcode;
    this.kinname = kinname;
    this.kinrelation = kinrelation;
    this.kinphone = kinphone;
}

    public String getProfilePicture() { return profilePicture; }
    public String getInitials() { return initials; }
    public String getLastname() { return lastname; }
    public String getFirstname() { return firstname; }
    public String getMiddlename() { return middlename; }
    public String getDob() { return dob; }
    public String getGender() { return gender; }
    public String getEmail() { return email; }
    public String getPhone() { return phone; }
    public String getAddressline1() { return addressline1; }
    public String getAddressline2() { return addressline2; }
    public String getAddressline3() { return addressline3; }
    public String getCity() { return city; }
    public String getState() { return state; }
    public String getCountry() { return country; }
    public String getPostalcode() { return postalcode; }
    public String getKinname() { return kinname; }
    public String getKinrelation() { return kinrelation; }
    public String getKinphone() { return kinphone; }
    public String getBloodgroup() { return bloodgroup; }
    public String getReligion() { return religion; }
    public String getOccupation() { return occupation; }
    public String getNationality() { return nationality; }
    // Getters and Setters (Omitted for brevity)
}

public class ExcelWriter {


    private static String columns[] = {
            "profilePicture",
            "initials",
            "lastname",
            "firstname",
            "middlename",
            "dob",
            "gender",
            "bloodgroup",
            "religion",
            "occupation",
            "nationality",
            "email",
            "phone",
            "addressline1",
            "addressline2",
            "addressline3",
            "city",
            "state",
            "country",
            "postalcode",
            "kinname",
            "kinrelation",
            "kinphone"
    };

    private static List<Employee> employees =  new ArrayList<>();

    // Initializing employees data to insert into the excel file


    static {
        Scanner input = new Scanner(System.in);
        System.out.println("enter number of employees: ");
        int noOfEmployee = input.nextInt();

        System.out.println("creating "+noOfEmployee+" employees.");
        System.out.println("creating employees");

        for (int i = 0; i < noOfEmployee; i++) {
            employees.add(new Employee(
                    FakerData.getAvatar(),
                    FakerData.getTitle(),
                    FakerData.getLastName(),
                    FakerData.getFirstName(),
                    FakerData.getMiddleName(),
                    FakerData.getDOB(),
                    FakerData.getGender(),
                    FakerData.getBloodGroup(),
                    FakerData.getReligion(),
                    FakerData.getOccupation(),
                    FakerData.getNationality(),
                    FakerData.getEmailId(),
                    FakerData.getPhoneNumber(),
                    FakerData.getAddressLine1(),
                    FakerData.getAddressLine2(),
                    FakerData.getAddressLine3(),
                    FakerData.getAddressCity(),
                    FakerData.getAddressState(),
                    FakerData.getAddressCountry(),
                    FakerData.getAddressZipCode(),
                    FakerData.getKinFullName(),
                    FakerData.getKinRelation(),
                    FakerData.getPhoneNumber()));
        }
        System.out.println("Employee created Successfully");
    }

    public static void main(String[] args) throws IOException, InvalidFormatException {


        // Create a Workbook
        Workbook workbook = new XSSFWorkbook(); // new HSSFWorkbook() for generating `.xlsx` file

        // Create a Sheet
        Sheet sheet = workbook.createSheet("Employee");

        // Create a Font for styling header cells
        Font headerFont = workbook.createFont();
        headerFont.setFontName("Calibri");
        headerFont.setFontHeightInPoints((short) 11);

        // Create a CellStyle with the font
        CellStyle headerCellStyle = workbook.createCellStyle();
        headerCellStyle.setFont(headerFont);

        // Create a Row
        Row headerRow = sheet.createRow(0);

        // Create cells
        for(int i = 0; i < columns.length; i++) {
            Cell cell = headerRow.createCell(i);
            cell.setCellValue(columns[i]);
            cell.setCellStyle(headerCellStyle);
        }

        // Create Other rows and cells with employees data
        int rowNum = 1;
        System.out.println(employees.size());


        System.out.println("writing data in to excel file");
            for (Employee employee : employees) {

                Row row = sheet.createRow(rowNum++);

                row.createCell(0).setCellValue(employee.getProfilePicture());
                row.createCell(1).setCellValue(employee.getInitials());
                row.createCell(2).setCellValue(employee.getLastname());
                row.createCell(3).setCellValue(employee.getFirstname());
                row.createCell(4).setCellValue(employee.getMiddlename());
                row.createCell(5).setCellValue(employee.getDob());
                row.createCell(6).setCellValue(employee.getGender());
                row.createCell(7).setCellValue(employee.getBloodgroup());
                row.createCell(8).setCellValue(employee.getReligion());
                row.createCell(9).setCellValue(employee.getOccupation());
                row.createCell(10).setCellValue(employee.getNationality());
                row.createCell(11).setCellValue(employee.getEmail());
                row.createCell(12).setCellValue(employee.getPhone());
                row.createCell(13).setCellValue(employee.getAddressline1());
                row.createCell(14).setCellValue(employee.getAddressline2());
                row.createCell(15).setCellValue(employee.getAddressline3());
                row.createCell(16).setCellValue(employee.getCity());
                row.createCell(17).setCellValue(employee.getState());
                row.createCell(18).setCellValue(employee.getCountry());
                row.createCell(19).setCellValue(employee.getPostalcode());
                row.createCell(20).setCellValue(employee.getKinname());
                row.createCell(21).setCellValue(employee.getKinrelation());
                row.createCell(22).setCellValue(employee.getKinphone());
            }

        // Resize all columns to fit the content size
        for(int i = 0; i < columns.length; i++) {
            sheet.autoSizeColumn(i);
        }

        // Write the output to a file
        FileOutputStream fileOut = new FileOutputStream("/home/qa/Desktop/poi-generated-file.xlsx");
        workbook.write(fileOut);
        fileOut.close();
        System.out.println("file writing complete");

        // Closing the workbook
        workbook.close();
    }*/
}
