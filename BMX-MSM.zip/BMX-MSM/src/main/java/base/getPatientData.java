package base;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class getPatientData {

        /**
         *
         * @return list of data containing map with key and value of data
         */
    public static Object[][] getData(String sheetName) throws IOException {

        FileInputStream fileInputStream = new FileInputStream(System.getProperty("user.dir") + "/src/main/resources/config.properties");
        Properties properties = new Properties();
        properties.load(fileInputStream);
        String data_driven = properties.getProperty("data_driven");
        String file_path = properties.getProperty("file_path");
        int record_count = Integer.parseInt(properties.getProperty("record_count"));
        Object[][] data;
        data = PatientDetailsBuilder.createData(record_count, sheetName);
        return data;
    }
}