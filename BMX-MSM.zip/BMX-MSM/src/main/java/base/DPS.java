package base;

import org.testng.annotations.DataProvider;
import testdata.PatientDataEnum;

import java.util.HashMap;
import java.util.Map;

public class DPS {
    @DataProvider(name = "data")
    public Object[][] dataSupplier(){
        System.out.println(PatientDetailsBuilder.createData(1,PatientDataEnum.dataType.BASIC_INFO.value));
            return PatientDetailsBuilder.createData(1,PatientDataEnum.dataType.BASIC_INFO.value);
    }
}