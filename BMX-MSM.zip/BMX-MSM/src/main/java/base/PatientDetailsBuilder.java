package base;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVRecord;
import testdata.BasicInfoDataFaker;
import testdata.IdentificationDataFaker;
import testdata.MedicalHistoryDataFaker;
import testdata.PatientDataEnum;
import testdata.PaymentTypeDataFaker;

import java.io.FileReader;
import java.io.Reader;
import java.util.*;

public class PatientDetailsBuilder {
    public static Object[][] data;
    public static List<String> keys = new ArrayList<>();

    public static List<HashMap<String, String>> createData(String filePath, String sheetName) {
         List<HashMap<String, String>> data = new ArrayList<>();
        try {
            Reader headerReader = new FileReader(filePath);
            Reader dataReader = new FileReader(filePath);


            List<String> keys = new ArrayList<>();

            Iterable<CSVRecord> headerRecords= CSVFormat.EXCEL.withHeader().withSkipHeaderRecord(false).parse(headerReader);
            Set<String> headers = headerRecords.iterator().next().toMap().keySet();
            for(String headerItem:headers){
                keys.add(headerItem);
            }
            headerReader.close();

            Iterable<CSVRecord> records = CSVFormat.RFC4180.withFirstRecordAsHeader().parse(dataReader);
            for (CSVRecord record : records) {
                HashMap<String, String> values = new HashMap<>();
                for(int i=0;i<keys.size();i++) {
                    values.put(keys.get(i),record.get(keys.get(i)));
                }
                data.add(values);
            }
            dataReader.close();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return data;
    }

    public static Object[][] createData(int count, String sheetName) {
        switch (sheetName){
            case "basic info":
                data = new Object[count][PatientDataEnum.basicInfo.values().length];

                keys.clear();
                keys.add("profilePicture");
                keys.add("initials");
                keys.add("lastname");
                keys.add("firstname");
                keys.add("middlename");
                keys.add("dob");
                keys.add("gender");
                keys.add("bloodgroup");
                keys.add("religion");
                keys.add("occupation");
                keys.add("nationality");
                keys.add("email");
                keys.add("phone");
                keys.add("addressline1");
                keys.add("addressline2");
                keys.add("addressline3");
                keys.add("city");
                keys.add("state");
                keys.add("country");
                keys.add("postalcode");
                keys.add("kinname");
                keys.add("kinrelation");
                keys.add("kinphone");

                for (int record = 0; record < count; record++) {
                    List<String> values = new ArrayList<>();
                    values.add(BasicInfoDataFaker.getAvatar());
                    values.add(BasicInfoDataFaker.getTitle());
                    values.add(BasicInfoDataFaker.getLastName());
                    values.add(BasicInfoDataFaker.getFirstName());
                    values.add(BasicInfoDataFaker.getMiddleName());
                    values.add(BasicInfoDataFaker.getDOB());
                    values.add(BasicInfoDataFaker.getGender());
                    values.add(BasicInfoDataFaker.getBloodGroup());
                    values.add(BasicInfoDataFaker.getReligion());
                    values.add(BasicInfoDataFaker.getOccupation());
                    values.add(BasicInfoDataFaker.getNationality());
                    values.add(BasicInfoDataFaker.getEmailId());
                    values.add(BasicInfoDataFaker.getPhoneNumber());
                    values.add(BasicInfoDataFaker.getAddressLine1());
                    values.add(BasicInfoDataFaker.getAddressLine2());
                    values.add(BasicInfoDataFaker.getAddressLine3());
                    values.add(BasicInfoDataFaker.getAddressCity());
                    values.add(BasicInfoDataFaker.getAddressState());
                    values.add(BasicInfoDataFaker.getAddressCountry());
                    values.add(BasicInfoDataFaker.getAddressZipCode());
                    values.add(BasicInfoDataFaker.getKinFullName());
                    values.add(BasicInfoDataFaker.getKinRelation());
                    values.add(BasicInfoDataFaker.getPhoneNumber());

                    Map<Object, Object> item = new HashMap<>();
                    for (int i = 0; i < keys.size(); i++) {
                        item.put(keys.get(i), values.get(i));
                        System.out.println("item length"+item.size());
                    }
                    data[record][0] =item;
                    System.out.println("data length"+data[0].length);
                }
                break;

            case "medical history info":
                data = new Object[count][PatientDataEnum.medicalHistoryInfo.values().length];

                keys.clear();
                keys.add("diseasename");
                keys.add("diseasenote");
                keys.add("procedurename");
                keys.add("proceduremonthyear");
                keys.add("medicationname");
                keys.add("allergyname");
                keys.add("addictionname");
                keys.add("fatherdiseasename");
                keys.add("motherdiseasename");
                keys.add("siblingdiseasename");
                keys.add("startdate");
                keys.add("enddate");

                for (int record = 0; record < count; record++) {
                    List<String> values = new ArrayList<>();
                    values.add(MedicalHistoryDataFaker.getDiseaseName());
                    values.add(MedicalHistoryDataFaker.getDiseaseNote());
                    values.add(MedicalHistoryDataFaker.getProcedureName());
                    values.add(MedicalHistoryDataFaker.getProcedureMonthYear());
                    values.add(MedicalHistoryDataFaker.getMedicationName());
                    values.add(MedicalHistoryDataFaker.getAllergyName());
                    values.add(MedicalHistoryDataFaker.getAddictionName());
                    values.add(MedicalHistoryDataFaker.getFatherDiseaseName());
                    values.add(MedicalHistoryDataFaker.getMotherDiseaseName());
                    values.add(MedicalHistoryDataFaker.getSiblingDiseaseName());
                    values.add(MedicalHistoryDataFaker.getStartDate());
                    values.add(MedicalHistoryDataFaker.getEndDate());

                    Map<Object, Object> item = new HashMap<>();
                    for (int i = 0; i < keys.size(); i++) {
                        item.put(keys.get(i), values.get(i));
                    }
                    data[record][0] =item;
                }
                break;

            case "identification info":
                data = new Object[count][PatientDataEnum.identificationInfo.values().length];
                keys.clear();
                keys.add("evidencetype");
                keys.add("evidenceid");
                keys.add("evidencedocument");

                for (int record = 0; record < count; record++) {
                    List<String> values = new ArrayList<>();
                    values.add(IdentificationDataFaker.getEvidenceType());
                    values.add(IdentificationDataFaker.getEvidenceId());
                    values.add(IdentificationDataFaker.getEvidenceDocument());

                    Map<Object, Object> item = new HashMap<>();
                    for (int i = 0; i < keys.size(); i++) {
                        item.put(keys.get(i), values.get(i));
                    }
                    data[record][0] =item;
                }
                break;

            case "payment plan info":
                data = new Object[count][PatientDataEnum.paymentPlanInfo.values().length];
                keys.clear();
                keys.add("paymenttype");
                keys.add("socialsecurityno");
                keys.add("insurancecompanyname");
                keys.add("planid");
                keys.add("planname");
                keys.add("companyname");
                keys.add("companyid");
                keys.add("contractid");
                keys.add("employeeid");
                keys.add("employeerole");
                keys.add("employeedepartment");
                keys.add("startdate");
                keys.add("enddate");
                keys.add("paymentplannote");
                keys.add("paymentdocument");

                for (int record = 0; record < count; record++) {
                    List<String> values = new ArrayList<>();
                    values.add(PaymentTypeDataFaker.getPaymentType());
                    values.add(PaymentTypeDataFaker.getSocialSecurityNo());
                    values.add(PaymentTypeDataFaker.getInsuranceCompanyName());
                    values.add(PaymentTypeDataFaker.getPlanId());
                    values.add(PaymentTypeDataFaker.getPlanName());
                    values.add(PaymentTypeDataFaker.getCompanyName());
                    values.add(PaymentTypeDataFaker.getCompanyId());
                    values.add(PaymentTypeDataFaker.getContractId());
                    values.add(PaymentTypeDataFaker.getEmployeeId());
                    values.add(PaymentTypeDataFaker.getEmployeeRole());
                    values.add(PaymentTypeDataFaker.getEmployeeDept());
                    values.add(PaymentTypeDataFaker.getStartDate());
                    values.add(PaymentTypeDataFaker.getEndDate());
                    values.add(PaymentTypeDataFaker.getPaymentPlanNote());
                    values.add(PaymentTypeDataFaker.getPaymentDocument());

                    Map<Object, Object> item = new HashMap<>();
                    for (int i = 0; i < keys.size(); i++) {
                        item.put(keys.get(i), values.get(i));
                    }
                    data[record][0] =item;
                }
                break;
            default:
                System.out.println("invalid type of data requested");
                break;
        }
        System.out.println("total data size"+data[0].length);
        return data;
    }
}
