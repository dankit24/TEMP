/**
 * File: RandomImage.java
 *
 * Description:
 * Create a random color image.
 *
 * @author Yusuf Shakeel
 * Date: 01-04-2014 tue
 */
package base;
import org.testng.annotations.Test;
import testdata.PatientDataEnum;

import java.io.File;
import java.io.IOException;
import java.awt.image.BufferedImage;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.Map;
import javax.imageio.ImageIO;


public class test{

    @Test(dataProvider = "data", dataProviderClass = DPS.class)
    public void printData(Map<Object, Object> data){
        System.out.println(data.get(PatientDataEnum.basicInfo.FIRST_NAME.value));
    }
}