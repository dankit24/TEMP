package base;


import com.opencsv.CSVWriter;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class CreatePatientCSV {
/*

    public static void writeDataAtOnce(String filePath, int records) {

        // first create file object for file placed at location
        // specified by filepath
        File file = new File(filePath);
        int noOfPatients = records;

        System.out.println("creating "+noOfPatients+" patient.");
        System.out.println("writing patient into: "+filePath);

        try {
            // create FileWriter object with file as parameter
            FileWriter outputfile = new FileWriter(file);

            // create CSVWriter object filewriter object as parameter

            CSVWriter writer = new CSVWriter(outputfile);

            // create a List which contains String array
            List<String[]> data = new ArrayList<String[]>();
            data.add(new String[]{
                    "profilePicture",
                    "initials",
                    "lastname",
                    "firstname",
                    "middlename",
                    "dob",
                    "gender",
                    "bloodgroup",
                    "religion",
                    "occupation",
                    "nationality",
                    "email",
                    "phone",
                    "addressline1",
                    "addressline2",
                    "addressline3",
                    "city",
                    "state",
                    "country",
                    "postalcode",
                    "kinname",
                    "kinrelation",
                    "kinphone",
                    "evidencepicture",
                    "sspicture",
                    "insurancepicture",
                    "ccpicture"
            });
            for(int i=0;i<noOfPatients;i++){
                data.add(new String[]{
                        FakerData.getAvatar(),
                        FakerData.getTitle(),
                        FakerData.getLastName(),
                        FakerData.getFirstName(),
                        FakerData.getMiddleName(),
                        FakerData.getDOB(),
                        FakerData.getGender(),
                        FakerData.getBloodGroup(),
                        FakerData.getReligion(),
                        FakerData.getOccupation(),
                        FakerData.getNationality(),
                        FakerData.getEmailId(),
                        FakerData.getPhoneNumber(),
                        FakerData.getAddressLine1(),
                        FakerData.getAddressLine2(),
                        FakerData.getAddressLine3(),
                        FakerData.getAddressCity(),
                        FakerData.getAddressState(),
                        FakerData.getAddressCountry(),
                        FakerData.getAddressZipCode(),
                        FakerData.getKinFullName(),
                        FakerData.getKinRelation(),
                        FakerData.getPhoneNumber(),
                        FakerData.getEvidencepicture(),
                        FakerData.getPaymentpicture(),
                        FakerData.getPaymentpicture(),
                        FakerData.getPaymentpicture()
                });
            }
            writer.writeAll(data);

            // closing writer connection
            writer.close();
            System.out.println("writing done");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
*/
}