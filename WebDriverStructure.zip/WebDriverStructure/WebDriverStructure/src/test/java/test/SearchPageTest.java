package test;

import base.ScreenRecorderUtil;
import base.TestUtils;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import page.SearchPage;

public class SearchPageTest extends TestBase {
    SearchPage searchPage;
    @BeforeMethod
    public void setUpLogger() {
        initialization();
        searchPage = new SearchPage();
    }
    @Test(priority = 1)
    public void verifyPageTitle() throws Exception {
        String title = searchPage.validateSearchPageTitle();
        Assert.assertEquals(title, "Google");
        Thread.sleep(1000);
        TestUtils.runTimeInfo("error","error message");
        Thread.sleep(1000);
        TestUtils.runTimeInfo("warning"," warning message");
        Thread.sleep(1000);
        TestUtils.runTimeInfo("info","info message");
        Thread.sleep(1000);
        tearDown();
    }
    @Test(priority = 2)
    public void searchTest() throws Exception {
        Thread.sleep(1000);
        TestUtils.runTimeInfo("error","error message");
        Thread.sleep(1000);
        TestUtils.runTimeInfo("warning"," warning message");
        Thread.sleep(1000);
        TestUtils.runTimeInfo("info","info message");
        Thread.sleep(1000);
        searchPage.searchQuery("bosleo");
        Thread.sleep(2000);
        TestUtils.runTimeInfo("error","error message");
        Thread.sleep(1000);
        TestUtils.runTimeInfo("warning"," warning message");
        Thread.sleep(1000);
        TestUtils.runTimeInfo("info","info message");
        Thread.sleep(1000);
        tearDown();
    }
}
