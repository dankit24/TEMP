package base;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Arrays;

public class TestListener implements ITestListener {
    StringWriter stringWriter = new StringWriter();

    public void onTestStart(ITestResult result) {
        try {
            TestUtils.loadGrowl();
            ScreenRecorderUtil.startRecord(result.getMethod().getMethodName());
        } catch (Exception e) {
            e.printStackTrace();
        }
        log.startTestCase(result.getMethod().getMethodName());
    }

    @Override
    public void onTestSuccess(ITestResult result) {
        try {
            ScreenRecorderUtil.stopRecord();
        } catch (Exception e) {
            e.printStackTrace();
        }
        log.endTestCase(result.getMethod().getMethodName());
    }

    @Override
    public void onTestFailure(ITestResult result) {
        try {
            ScreenRecorderUtil.stopRecord();
        } catch (Exception e) {
            e.printStackTrace();
        }
        result.getThrowable().printStackTrace(new PrintWriter(stringWriter));

        log.error("error in test: "+ result.getMethod().getMethodName());
        log.error("error description:"+ stringWriter.toString());
    }

    @Override
    public void onTestSkipped(ITestResult result) {
        log.warn("test skipped: "+result.getMethod().getMethodName());
    }

    @Override
    public void onTestFailedButWithinSuccessPercentage(ITestResult result) {

    }

    @Override
    public void onTestFailedWithTimeout(ITestResult result) {

    }

    @Override
    public void onStart(ITestContext context) {

    }

    @Override
    public void onFinish(ITestContext context) {

    }
}
