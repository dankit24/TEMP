package test;

import base.testBase;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;
import page.googleHomePage;

public class googleHomePageTest extends testBase {
    @Test
    public void googleSearchTest(){
        googleHomePage page = PageFactory.initElements(getDriver(), googleHomePage.class);
        page.insertSearchQuery("bosleo").getSearchResults();
    }
}
