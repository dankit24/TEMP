package test;

import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import page.SearchPage;

public class SearchPageTest extends TestBase {
    SearchPage searchPage;
    @BeforeMethod
    public void setUp() {
        initialization();
        searchPage = new SearchPage();
    }
    @Test(priority = 1)
    public void verifyPageTitle(){
        String title = searchPage.validateSearchPageTitle();
        Assert.assertEquals(title, "bosleo");
    }
    @Test(priority = 2)
    public void searchTest(){
        searchPage.searchQuery("bosleo");
    }
}
