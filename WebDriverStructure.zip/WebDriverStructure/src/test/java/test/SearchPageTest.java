package test;

import base.Log;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import page.SearchPage;

public class SearchPageTest extends TestBase {
    SearchPage searchPage;
    @BeforeMethod
    public void setUpLogger() {
        initialization();
        searchPage = new SearchPage();
    }
    @Test(priority = 1)
    public void verifyPageTitle(){
        String title = searchPage.validateSearchPageTitle();
        Assert.assertEquals(title, "Google");
        tearDown();
    }
    @Test(priority = 2)
    public void searchTest() throws InterruptedException {
        searchPage.searchQuery("bosleo");
        tearDown();

    }
}
