package test;
import base.WebEventListener;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.apache.log4j.xml.DOMConfigurator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.logging.*;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.log4testng.Logger;

import java.util.Date;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;

public class TestBase {
    public static WebDriver driver;
    public static EventFiringWebDriver e_driver;
    public static WebEventListener eventListener;


    public void initialization() {
        WebDriverManager.chromedriver().setup();
       // System.setProperty("webdriver.chrome.logfile", "/home/qa/Downloads/WebDriverStructure/logs/browser.logs");

        driver = new ChromeDriver();

        e_driver = new EventFiringWebDriver(driver);
        eventListener = new WebEventListener();
        e_driver.register(eventListener);
        driver = e_driver;


        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
        driver.get("https://www.google.com/");
    }

    public void tearDown() {
        driver.quit();
    }
}
