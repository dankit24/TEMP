package base;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.ITestContext;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;

public class testBase {
    WebDriver driver;
    @BeforeSuite
    public void beforeSuite(ITestContext context){
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.google.com/");
        context.setAttribute("webDriver", driver);
    }
    @AfterSuite
    public void tearDown(){
        driver.quit();
    }
    @BeforeTest
    public WebDriver getDriver(){
        return driver;
    }
}
