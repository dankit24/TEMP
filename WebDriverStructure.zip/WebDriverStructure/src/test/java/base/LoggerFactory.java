package base;

import org.slf4j.ILoggerFactory;
import org.slf4j.Logger;

public class LoggerFactory implements ILoggerFactory {
    @Override
    public Logger getLogger(String s) {
        return null;
    }
}
