package page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.Map;

public class googleHomePage {
    WebDriver driver;
    private Map<String, String> data;
    private int timeout = 15;
    private final String pageLoadedText = "";
    private final String pageUrl = "/";

    @FindBy(xpath = "/html/body/div/div[4]/form/div[2]/div[1]/div[1]/div/div[2]/input")
    @CacheLookup
    WebElement searchField;

    @FindBy(xpath = "/html/body/div/div[4]/form/div[2]/div[1]/div[3]/center/input[1]/a/b/c")
    @CacheLookup
    WebElement searchButton;

    public googleHomePage(){}
    public googleHomePage(WebDriver driver){
        this();
        this.driver = driver;
    }
    public googleHomePage(WebDriver driver, Map<String, String> data){
        this(driver);
        this.data = data;
    }
    public googleHomePage(WebDriver driver, Map<String, String> data, int timeout){
        this(driver, data);
        this.timeout = timeout;
    }

    public googleHomePage insertSearchQuery(String searchQuery) {
        searchField.sendKeys(searchQuery);
        return this;
    }

    public googleHomePage getSearchResults() {
        searchButton.click();
        return this;
    }

    public googleHomePage verifyPageLoaded() {
        (new WebDriverWait(driver, timeout)).until(new ExpectedCondition<Boolean>() {
            public Boolean apply(WebDriver d) {
                return d.getPageSource().contains(pageLoadedText);
            }
        });
        return this;
    }

    public googleHomePage verifyPageUrl() {
        (new WebDriverWait(driver, timeout)).until(new ExpectedCondition<Boolean>() {
            public Boolean apply(WebDriver d) {
                return d.getCurrentUrl().contains(pageUrl);
            }
        });
        return this;
    }

}
