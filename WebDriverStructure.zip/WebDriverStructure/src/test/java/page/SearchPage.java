package page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import test.TestBase;

import java.util.Map;

public class SearchPage extends TestBase {

    @FindBy(xpath = "/html/body/div/div[4]/form/div[2]/div[1]/div[1]/div/div[2]/input")
    WebElement searchField;
    @FindBy(xpath = "/html/body/div/div[4]/form/div[2]/div[1]/div[3]/center/input[1]")
    WebElement searchButton;

public SearchPage(){ PageFactory.initElements(driver, this); }

public String validateSearchPageTitle(){ return driver.getTitle(); }

public void searchQuery(String query){
    searchField.sendKeys(query);
    searchButton.click();
    }


}
