jquery-growl-selenium-example
=============================

Example using jGrowl with Selenium

If you want to see what this project does, just watch this video:
https://vimeo.com/99202337
If the video doesn't play, there is download link


Running it
=============================

Run using Maven command ```clean compile test-compile test``` and project will be executed by Maven Surefire plugin.

Purpose
=============================

The purpose of this project is to show that jQuery and jGrowl can be injected dynamically into a Selenium WebDriver instance and executed on any web page.
