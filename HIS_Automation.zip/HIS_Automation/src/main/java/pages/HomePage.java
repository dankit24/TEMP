package pages;

import base.TestBase;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HomePage extends TestBase {
    @FindBy(xpath = "/html/body/div/div[4]/form/div[2]/div[1]/div[1]/div/div[2]/input") WebElement searchField;
    @FindBy(xpath = "/html/body/div/div[4]/form/div[2]/div[1]/div[2]/div[2]/div[2]/center/input[1]") WebElement searchButton;

    public HomePage() { PageFactory.initElements(driver, this); }

    public WebElement getSearchField() {
        return searchField;
    }

    public WebElement getSearchButton() {
        return searchButton;
    }
}
