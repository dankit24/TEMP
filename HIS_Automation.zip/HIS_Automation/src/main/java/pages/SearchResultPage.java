package pages;

import base.TestBase;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SearchResultPage extends TestBase {
    @FindBy(xpath = "/html/body/div[3]/form/div[2]/div[1]/div[2]/div/div[2]/input") WebElement searchField;
    @FindBy(xpath = "/html/body/div[7]/div[3]/div[10]/div[1]/div[3]/div/div[1]/div/div[1]/div/div[1]/div[2]/div[2]/div[1]/div/div/div[1]/span") WebElement SearchResult;

    public SearchResultPage() {
        PageFactory.initElements(driver,this);
    }

    public WebElement getSearchField() {
        return searchField;
    }

    public WebElement getSearchResult() {
        return SearchResult;
    }
}
