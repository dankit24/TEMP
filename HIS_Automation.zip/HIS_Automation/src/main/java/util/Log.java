package util;

import org.apache.log4j.*;

public class Log {
    // Initialize Log4j logs
    private static Logger infoLogger = Logger.getLogger("infoLogConfig");
    private static Logger errorLogger = Logger.getLogger("errorLogConfig");
    private static Logger debugLogger = Logger.getRootLogger();
    private static Logger fatalLogger = Logger.getRootLogger();
    private static Logger warningLogger = Logger.getRootLogger();

    // This is to print Log for the beginning of the test case, as we usually run so many test cases as a test suite
    public static void startTestCase(String sTestCaseName){

        infoLogger.info("****************************************************************************************");

        infoLogger.info("****************************************************************************************");

        infoLogger.info("$$$$$$$$$$$$$$$$$$$$$                 "+sTestCaseName+ "       $$$$$$$$$$$$$$$$$$$$$$$$$");

        infoLogger.info("****************************************************************************************");

        infoLogger.info("****************************************************************************************");

    }

    //This is to print Log for the ending of the test case
    public static void endTestCase(String sTestCaseName){
        infoLogger.info("XXXXXXXXXXXXXXXXXXXXXXX             "+"-E---N---D-"+"             XXXXXXXXXXXXXXXXXXXXXX");
    }

    // Need to create these methods, so that they can be called
    public static void info(String message){ infoLogger.info(message); }

    public static void warn(String message) { warningLogger.warn(message); }

    public static void error(String message) { errorLogger.error(message); }

    public static void fatal(String message) { fatalLogger.fatal(message); }

    public static void debug(String message) { debugLogger.debug(message); }

}