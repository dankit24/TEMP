package util;

import base.TestBase;
import org.openqa.selenium.JavascriptExecutor;

public class Growl extends TestBase {
    private static JavascriptExecutor js;
    public static void loadGrowl() throws InterruptedException {
        js = (JavascriptExecutor) driver;
        // Check for jQuery on the page, add it if need be
        js.executeScript("if (!window.jQuery) {"
                + "var jquery = document.createElement('script'); jquery.type = 'text/javascript';"
                + "jquery.src = 'https://ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js';"
                + "document.getElementsByTagName('head')[0].appendChild(jquery);" + "}");
        Thread.sleep(5000);
        //add jquery-growl.js file
        js.executeScript("var jgrowl = document.createElement('script'); jgrowl.type = 'text/javascript';jgrowl.src = 'https://the-internet.herokuapp.com/js/vendor/jquery.growl.js';document.getElementsByTagName('head')[0].appendChild(jgrowl);");
        Thread.sleep(5000);
        // Use jQuery to add jquery-growl styles to the page
        js.executeScript("$('head').append(\"<link rel=\\\"stylesheet\\\" type=\\\"text/css\\\" href=\\\"https://the-internet.herokuapp.com/css/jquery.growl.css\\\">\");");
        Thread.sleep(5000);
    }
    public static void error(String message) throws InterruptedException {
        Thread.sleep(1000);
        js.executeScript("$.growl.error({ title: 'Error', message: '" + message + "' });");
        Thread.sleep(1000);
    }
    public static void info(String message) throws InterruptedException {
        Thread.sleep(1000);
        js.executeScript("$.growl.notice({ title: 'Info', message: '" + message + "' });");
        Thread.sleep(1000);
    }
    public static void warning(String message) throws InterruptedException {
        Thread.sleep(1000);
        js.executeScript("$.growl.warning({ title: 'Warning!', message: '" + message + "' });");
        Thread.sleep(1000);
    }
}
