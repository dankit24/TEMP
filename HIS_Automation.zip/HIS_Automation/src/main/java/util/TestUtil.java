package util;

import org.openqa.selenium.WebElement;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;
import java.util.Properties;

import static org.testng.Assert.assertEquals;

public class TestUtil {
    private static String property;

    public static String getProperty(String key) throws IOException {
        FileInputStream fileInputStream = new FileInputStream(System.getProperty("user.dir")+"/src/main/java/config/config.properties");
        Properties properties = new Properties();
        properties.load(fileInputStream);
        property =  properties.getProperty(key);
        return property;
    }

    public static void selectFromDropdown(List<WebElement> dropDownOptions, WebElement dropDown, String selection) throws InterruptedException {

        System.out.println(dropDownOptions.size());

        for(int j=0;j<dropDownOptions.size();j++){
            System.out.println(dropDownOptions.get(j).getText());
            if (dropDownOptions.get(j).getText().equals(selection)) {
                Thread.sleep(1000);
                dropDownOptions.get(j).click();
                Thread.sleep(1000);
                break;
            }
        }
        Thread.sleep(1000);
        assertEquals(dropDown.getText(), selection);
        System.out.println("Assertion Successful");
    }
}
