package base;

import io.github.bonigarcia.wdm.ChromeDriverManager;
import io.github.bonigarcia.wdm.FirefoxDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.testng.annotations.Test;
import util.TestUtil;
import util.WebEventListener;

import java.io.IOException;

public class TestBase {
    public static WebDriver driver;
    public static EventFiringWebDriver e_driver;
    private static String baseURL;
    private static String headless;
    private static  String browser;

    @Test
    public static void init() throws IOException {
        baseURL = TestUtil.getProperty("dev_url");
        headless = TestUtil.getProperty("headless");
        browser = TestUtil.getProperty("browser");
    if("chrome".equals(browser)){
        ChromeDriverManager.chromedriver().setup();

        if("true".equals(headless)){
            ChromeOptions options = new ChromeOptions();
            options.addArguments("--headless");
            driver = new ChromeDriver(options);
        }
        else {
        driver = new ChromeDriver();
        }
    }

    if("firefox".equals(browser)){
            FirefoxDriverManager.firefoxdriver().setup();

            if("true".equals(headless)){
                FirefoxOptions options = new FirefoxOptions();
                options.addArguments("--headless");
                driver = new FirefoxDriver(options);
            }
            else {
                driver = new FirefoxDriver();
            }
        }


        e_driver = new EventFiringWebDriver(driver);
        WebEventListener eventListener = new WebEventListener();
        e_driver.register(eventListener);
        driver = e_driver;
        driver.manage().window().maximize();
        driver.get(baseURL);
    }
}
