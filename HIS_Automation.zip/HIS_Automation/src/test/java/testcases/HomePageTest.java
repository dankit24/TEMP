package testcases;

import base.TestBase;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.HomePage;
import pages.SearchResultPage;

public class HomePageTest extends TestBase {
    HomePage homePage;
    SearchResultPage searchResultPage;
    @Test(priority = 1)
    public void verifyTitle() throws InterruptedException {
        homePage = new HomePage();
        Thread.sleep(2000);
        Assert.assertEquals( "test" ,driver.getTitle());
        Thread.sleep(2000);
    }
    @Test(priority = 2)
    public void searchTest() throws InterruptedException {
        homePage = new HomePage();
        Thread.sleep(2000);
        homePage.getSearchField().sendKeys("bosleo");
        Thread.sleep(2000);
        homePage.getSearchButton().click();
        Thread.sleep(2000);

    }
    @Test(priority = 3)
    public void verifySearchFieldContent() throws InterruptedException {
        searchResultPage = new SearchResultPage();
        Thread.sleep(2000);
        Assert.assertEquals("bosleo1", searchResultPage.getSearchField().getAttribute("value"));
        Thread.sleep(2000);
    }

    @Test(priority = 4)
    public void verifySearchResults() throws InterruptedException {
        searchResultPage = new SearchResultPage();
        Thread.sleep(2000);
        Assert.assertEquals("BosLeo Technology Private Limited1", searchResultPage.getSearchResult().getText());
        Thread.sleep(2000);
    }
}
