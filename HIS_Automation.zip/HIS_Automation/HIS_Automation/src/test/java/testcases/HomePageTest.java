package testcases;

import base.TestBase;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.HomePage;

public class HomePageTest extends TestBase {
    HomePage homePage;
    @Test(priority = 1)
    public void verifyTitle() throws InterruptedException {
        homePage = new HomePage();
        Thread.sleep(2000);
        Assert.assertEquals(driver.getTitle(), "Google");
        Thread.sleep(2000);
    }
    @Test(priority = 2)
    public void searchTest() throws InterruptedException {
        homePage = new HomePage();
        Thread.sleep(2000);
        homePage.getSearchField().sendKeys("bosleo");
        Thread.sleep(2000);
        homePage.getSearchButton().click();
        Thread.sleep(2000);

    }
}
