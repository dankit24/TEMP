package util;

import java.io.IOException;

import org.apache.log4j.ConsoleAppender;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PatternLayout;
import org.apache.log4j.RollingFileAppender;

public class LoggerConfiguration {

    private static final Logger log = Logger.getLogger(LoggerConfiguration.class);

    public static void rootLogger()
    {
        //This is the root logger provided by log4j
        Logger rootLogger = Logger.getRootLogger();
        rootLogger.setLevel(Level.ALL);
        //Define log pattern layout
        PatternLayout layout = new PatternLayout("%d{ISO8601} [%t] %-5p %c %x - %m%n");
        //Add console appender to root logger
        rootLogger.addAppender(new ConsoleAppender(layout));
        try{
            //Define file appender with layout and output log file name
            RollingFileAppender fileAppender = new RollingFileAppender(layout, System.getProperty("user.dir")+"/logs/system.log");
            //Add the appender to root logger
            rootLogger.addAppender(fileAppender);
        }
        catch (IOException e)
        {
            System.out.println("Failed to add appender !!");
        }
    }
}
