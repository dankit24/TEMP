curl 'http://localhost:5556/selenium-server/driver/?cmd=shutDownSeleniumServer'
curl 'http://localhost:4444/lifecycle-manager?action=shutdown'