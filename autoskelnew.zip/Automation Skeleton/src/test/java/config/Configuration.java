package config;

public class Configuration {

    public static String baseURL = "www.google.com";
    public static final String DEFAULT_OS = "LINUX";
}
