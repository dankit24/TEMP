#!/bin/sh

echo "WebDriver Grid Hub on 4444"
echo ""

echo "*********************************************"
echo "*"
echo "* WebDriver grid Hub instance."
echo "*"
echo "*  http://localhost:4444/grid/console"
echo "*"
echo "*********************************************"
echo ""

export run_directory=./lib

jarfile=selenium-server-standalone-3.9.1.jar

if [ -z "${JAVA_HOME+xxx}" ]; then
  echo JAVA_HOME is not set at all;
  exit 1
fi

echo $JAVA_HOME
export PATH="$JAVA_HOME/bin:$PATH"
echo $PATH

cd $run_directory
nohup 2> /home/qa/Pictures/AutomationStrucure/gridLogs/hubLog.out 1> /home/qa/Pictures/AutomationStrucure/gridLogs/hubLog.err $JAVA_HOME/bin/java -jar $jarfile -role hub -hubConfig ../grid_hub.json

echo 'Done'
exit