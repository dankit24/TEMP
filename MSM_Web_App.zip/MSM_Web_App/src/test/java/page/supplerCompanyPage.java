package page;

public class supplerCompanyPage {
}
