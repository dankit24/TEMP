package page;

import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class supplerCompanyPage {
    WebDriver driver;

    public supplerCompanyPage(WebDriver driver) {
        this.driver = driver;
    }

    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/app-sidebar/aside/div[3]/ul/li[4]/a")
    WebElement supplierAccountSetupTab;
    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/app-sidebar/aside/div[3]/ul/li[4]/a/ul/li[1]/a")
    WebElement supplierCompanySubTab;
    @FindBy(xpath = "")
    WebElement supplierCompanyTaxID;
    @FindBy(xpath = "")
    WebElement supplierCompanyName;
    @FindBy(xpath = "")
    WebElement hospitalSelect;
    @FindBy(xpath = "")
    WebElement hospitalSelected;
    @FindBy(xpath = "")
    WebElement supplierCompanyTypeSelect;
    @FindBy(xpath = "")
    WebElement supplierCompanyTypeSelected;
    @FindBy(xpath = "")
    WebElement notes;
    @FindBy(xpath = "")
    WebElement email;
    @FindBy(xpath = "")
    WebElement socialMediaID;
    @FindBy(xpath = "")
    WebElement website;
    @FindBy(xpath = "")
    WebElement mAddressLine1;
    @FindBy(xpath = "")
    WebElement mAddressLine2;
    @FindBy(xpath = "")
    WebElement mAddressLine3;
    @FindBy(xpath = "")
    WebElement mCity;
    @FindBy(xpath = "")
    WebElement mState;
    @FindBy(xpath = "")
    WebElement mCountry;
    @FindBy(xpath = "")
    WebElement mPostalCode;
    @FindBy(xpath = "")
    WebElement mPhoneNumber;

    public void addNewSupplierCompany(JSONObject data) throws InterruptedException {

        /*System.out.println(dataArray);
        int arrayLength = dataArray.length();
        System.out.println(arrayLength);

        for(int i=0;i<arrayLength;i++){
            JSONObject data = (JSONObject) dataArray.get(i);*/
        this.supplierAccountSetupTab.click();
        this.supplierCompanySubTab.click();
        this.supplierCompanyTaxID.sendKeys(data.get("supplierCompanyTaxID").toString());
        this.supplierCompanyName.sendKeys(data.get("supplierCompanyName").toString());
        Thread.sleep(2000);
        this.hospitalSelect.click();
        Thread.sleep(2000);
        this.hospitalSelected.click();
        Thread.sleep(2000);
        this.supplierCompanyTypeSelect.click();
        Thread.sleep(2000);
        this.supplierCompanyTypeSelected.click();
        Thread.sleep(2000);
        this.notes.sendKeys(data.get("notes").toString());
        this.email.sendKeys(data.get("email").toString());
        this.socialMediaID.sendKeys(data.get("socialMediaID").toString());
        this.website.sendKeys(data.get("website").toString());
        this.mAddressLine1.sendKeys(data.get("mAddressLine1").toString());
        this.mAddressLine2.sendKeys(data.get("mAddressLine2").toString());
        this.mAddressLine3.sendKeys(data.get("mAddressLine3").toString());
        this.mCity.sendKeys(data.get("mCity").toString());
        this.mState.sendKeys(data.get("mState").toString());
        this.mCountry.sendKeys(data.get("mCountry").toString());
        this.mPostalCode.sendKeys(data.get("mPostalCode").toString());
        this.mPhoneNumber.sendKeys(data.get("mPhoneNumber").toString());
    }
//}
}
