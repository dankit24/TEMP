package page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class navigationBar {
    public static WebDriver driver;

    public navigationBar(WebDriver driver) { this.driver = driver;}

    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/app-sidebar/aside/div[3]/ul/li[1]/a") WebElement dashbordTab;

    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/app-sidebar/aside/div[3]/ul/li[2]/a") WebElement corpSetupTab;
    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/app-sidebar/aside/div[3]/ul/li[2]/ul/li[1]/a") WebElement companySubTab;
    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/app-sidebar/aside/div[3]/ul/li[2]/ul/li[2]/a") WebElement hospitalSubTab;
    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/app-sidebar/aside/div[3]/ul/li[2]/ul/li[3]/a") WebElement teamSubTab;
    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/app-sidebar/aside/div[3]/ul/li[2]/ul/li[4]/a") WebElement clinicSubTab;

    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/app-sidebar/aside/div[3]/ul/li[3]/a") WebElement customerAccountSetupTab;
    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/app-sidebar/aside/div[3]/ul/li[3]/a/ul/li[1]/a") WebElement clientCompanySubTab;
    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/app-sidebar/aside/div[3]/ul/li[3]/a/ul/li[2]/a") WebElement clientSubsidiarySubTab;
    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/app-sidebar/aside/div[3]/ul/li[3]/a/ul/li[3]/a") WebElement clientBusinessUnitSubTab;
    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/app-sidebar/aside/div[3]/ul/li[3]/a/ul/li[4]/a") WebElement clientEmployeeSubTab;

    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/app-sidebar/aside/div[3]/ul/li[4]/a") WebElement supplierAccountSetupTab;
    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/app-sidebar/aside/div[3]/ul/li[4]/a/ul/li[1]/a") WebElement supplierCompanySubTab;
    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/app-sidebar/aside/div[3]/ul/li[4]/a/ul/li[2]/a") WebElement supplierSubsidiarySubTab;
    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/app-sidebar/aside/div[3]/ul/li[4]/a/ul/li[3]/a") WebElement supplierBusinessUnitSubTab;

    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/app-sidebar/aside/div[3]/ul/li[5]/a") WebElement medicalCatalogTab;
    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/app-sidebar/aside/div[3]/ul/li[5]/a/ul/li[1]/a") WebElement catalogSubTab;
    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/app-sidebar/aside/div[3]/ul/li[5]/a/ul/li[2]/a") WebElement catalogElementSubTab;


    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/app-sidebar/aside/div[3]/ul/li[6]/a") WebElement medicalServiceTab;
    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/app-sidebar/aside/div[3]/ul/li[6]/a/ul/li[1]/a") WebElement contractSubTab;
    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/app-sidebar/aside/div[3]/ul/li[6]/a/ul/li[2]/a") WebElement servicePackageSubTab;
    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/app-sidebar/aside/div[3]/ul/li[6]/a/ul/li[3]/a") WebElement guidelinesSubTab;
    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/app-sidebar/aside/div[3]/ul/li[6]/a/ul/li[4]/a") WebElement contractPackageSubTab;

    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/app-sidebar/aside/div[3]/ul/li[7]/a") WebElement marketingTab;
    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/app-sidebar/aside/div[3]/ul/li[7]/a/ul/li[1]/a") WebElement corpCampaignSubTab;
    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/app-sidebar/aside/div[3]/ul/li[7]/a/ul/li[2]/a") WebElement serviceDeliverySubTab;
    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/app-sidebar/aside/div[3]/ul/li[7]/a/ul/li[3]/a") WebElement campaignListSubTab;

    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/app-sidebar/aside/div[3]/ul/li[8]/a") WebElement patinetCheckUpTab;
    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/app-sidebar/aside/div[3]/ul/li[8]/a/ul/li[1]/a") WebElement checkupPlanSubTab;
    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/app-sidebar/aside/div[3]/ul/li[8]/a/ul/li[2]/a") WebElement patientVisitSubTab;
    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/app-sidebar/aside/div[3]/ul/li[8]/a/ul/li[3]/a") WebElement labResultSubTab;

    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/app-sidebar/aside/div[3]/ul/li[9]/a") WebElement userManagementTab;

    public void naviagtionTest() throws InterruptedException {
        Thread.sleep(2000);
        this.dashbordTab.click();

        Thread.sleep(2000);
        this.corpSetupTab.click();
        Thread.sleep(2000);
        this.companySubTab.click();
        this.hospitalSubTab.click();
        this.teamSubTab.click();
        this.clinicSubTab.click();

        Thread.sleep(2000);
        this.customerAccountSetupTab.click();
        Thread.sleep(2000);
        this.clientCompanySubTab.click();
        this.clientSubsidiarySubTab.click();
        this.clientBusinessUnitSubTab.click();
        this.clientEmployeeSubTab.click();

        Thread.sleep(2000);
        this.supplierAccountSetupTab.click();
        Thread.sleep(2000);
        this.supplierCompanySubTab.click();
        this.supplierSubsidiarySubTab.click();
        this.supplierBusinessUnitSubTab.click();

        Thread.sleep(2000);
        this.medicalCatalogTab.click();
        Thread.sleep(2000);
        this.catalogSubTab.click();
        this.catalogElementSubTab.click();

        Thread.sleep(2000);
        this.medicalServiceTab.click();
        Thread.sleep(2000);
        this.contractSubTab.click();
        this.servicePackageSubTab.click();
        this.guidelinesSubTab.click();
        this.contractPackageSubTab.click();

        Thread.sleep(2000);
        this.marketingTab.click();
        Thread.sleep(2000);
        this.corpCampaignSubTab.click();
        this.serviceDeliverySubTab.click();
        this.campaignListSubTab.click();

        Thread.sleep(2000);
        this.patinetCheckUpTab.click();
        Thread.sleep(2000);
        this.checkupPlanSubTab.click();
        this.patientVisitSubTab.click();
        this.labResultSubTab.click();

        Thread.sleep(2000);
        this.userManagementTab.click();
    }

    public void navigateTab(WebElement element){
        element.click();
    }

}
