package page;

import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class corpClinicPage {
    WebDriver driver;

    public corpClinicPage(WebDriver driver) {
        this.driver = driver;
    }

    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/app-sidebar/aside/div[3]/ul/li[2]/a")
    WebElement corpSetupTab;
    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/app-sidebar/aside/div[3]/ul/li[2]/ul/li[4]/a")
    WebElement clinicSubTab;
    @FindBy(xpath = "")
    WebElement companySelect;
    @FindBy(xpath = "")
    WebElement companySelected;
    @FindBy(xpath = "")
    WebElement hospitalSelect;
    @FindBy(xpath = "")
    WebElement hospitalSelected;
    @FindBy(xpath = "")
    WebElement clinicName;
    @FindBy(xpath = "")
    WebElement email;
    @FindBy(xpath = "")
    WebElement socialMediaID;
    @FindBy(xpath = "")
    WebElement website;
    @FindBy(xpath = "")
    WebElement mAddressLine1;
    @FindBy(xpath = "")
    WebElement mAddressLine2;
    @FindBy(xpath = "")
    WebElement mAddressLine3;
    @FindBy(xpath = "")
    WebElement mCity;
    @FindBy(xpath = "")
    WebElement mState;
    @FindBy(xpath = "")
    WebElement mCountry;
    @FindBy(xpath = "")
    WebElement mPostalCode;
    @FindBy(xpath = "")
    WebElement mPhoneNumber;

    public void addNewClinic(JSONObject data) throws InterruptedException {

        /*System.out.println(dataArray);
        int arrayLength = dataArray.length();
        System.out.println(arrayLength);

        for(int i=0;i<arrayLength;i++){
            JSONObject data = (JSONObject) dataArray.get(i);*/
        this.corpSetupTab.click();
        this.clinicSubTab.click();
        Thread.sleep(2000);
        this.companySelect.click();
        Thread.sleep(2000);
        this.companySelected.click();
        Thread.sleep(2000);
        this.hospitalSelect.click();
        Thread.sleep(2000);
        this.hospitalSelected.click();
        Thread.sleep(2000);
        this.clinicName.sendKeys(data.get("clinicName").toString());
        this.email.sendKeys(data.get("email").toString());
        this.socialMediaID.sendKeys(data.get("socialMediaID").toString());
        this.website.sendKeys(data.get("website").toString());
        this.mAddressLine1.sendKeys(data.get("mAddressLine1").toString());
        this.mAddressLine2.sendKeys(data.get("mAddressLine2").toString());
        this.mAddressLine3.sendKeys(data.get("mAddressLine3").toString());
        this.mCity.sendKeys(data.get("mCity").toString());
        this.mState.sendKeys(data.get("mState").toString());
        this.mCountry.sendKeys(data.get("mCountry").toString());
        this.mPostalCode.sendKeys(data.get("mPostalCode").toString());
        this.mPhoneNumber.sendKeys(data.get("mPhoneNumber").toString());
    }
//}
}
