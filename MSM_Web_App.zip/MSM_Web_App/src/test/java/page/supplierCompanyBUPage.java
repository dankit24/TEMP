package page;

import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class supplierCompanyBUPage {
    WebDriver driver;
    public supplierCompanyBUPage(WebDriver driver){this.driver=driver;}

    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/app-sidebar/aside/div[3]/ul/li[4]/a") WebElement supplierAccountSetupTab;
    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/app-sidebar/aside/div[3]/ul/li[4]/a/ul/li[3]/a") WebElement supplierBusinessUnitSubTab;
    @FindBy(xpath = "") WebElement supplierCompanySelect;
    @FindBy(xpath = "") WebElement supplierCompanySelected;
    @FindBy(xpath = "") WebElement supplierSubsidiarySelect;
    @FindBy(xpath = "") WebElement supplierSubsidiarySelected;
    @FindBy(xpath = "") WebElement businessUnitName;
    @FindBy(xpath = "") WebElement businessUnitTaxID;
    @FindBy(xpath = "") WebElement businessUnitTypeSelect;
    @FindBy(xpath = "") WebElement businessUnitTypeSelected;
    @FindBy(xpath = "") WebElement notes;
    @FindBy(xpath = "") WebElement email;
    @FindBy(xpath = "") WebElement socialMediaID;
    @FindBy(xpath = "") WebElement website;
    @FindBy(xpath = "") WebElement mAddressLine1;
    @FindBy(xpath = "") WebElement mAddressLine2;
    @FindBy(xpath = "") WebElement mAddressLine3;
    @FindBy(xpath = "") WebElement mCity;
    @FindBy(xpath = "") WebElement mState;
    @FindBy(xpath = "") WebElement mCountry;
    @FindBy(xpath = "") WebElement mPostalCode;
    @FindBy(xpath = "") WebElement mPhoneNumber;

    public void addNewSupplierBU(JSONObject data) throws InterruptedException {

        this.supplierAccountSetupTab.click();
        this.supplierBusinessUnitSubTab.click();
        Thread.sleep(2000);
        this.supplierCompanySelect.click();
        Thread.sleep(2000);
        this.supplierCompanySelected.click();
        Thread.sleep(2000);
        this.supplierSubsidiarySelect.click();
        Thread.sleep(2000);
        this.supplierSubsidiarySelected.click();
        Thread.sleep(2000);
        this.businessUnitName.sendKeys(data.get("businessUnitName").toString());
        this.businessUnitTaxID.sendKeys(data.get("businessUnitTaxID").toString());
        Thread.sleep(2000);
        this.businessUnitTypeSelect.click();
        Thread.sleep(2000);
        this.businessUnitTypeSelected.click();
        Thread.sleep(2000);
        this.notes.sendKeys(data.get("notes").toString());
        this.email.sendKeys(data.get("email").toString());
        this.socialMediaID.sendKeys(data.get("socialMediaID").toString());
        this.website.sendKeys(data.get("website").toString());
        this.mAddressLine1.sendKeys(data.get("mAddressLine1").toString());
        this.mAddressLine2.sendKeys(data.get("mAddressLine2").toString());
        this.mAddressLine3.sendKeys(data.get("mAddressLine3").toString());
        this.mCity.sendKeys(data.get("mCity").toString());
        this.mState.sendKeys(data.get("mState").toString());
        this.mCountry.sendKeys(data.get("mCountry").toString());
        this.mPostalCode.sendKeys(data.get("mPostalCode").toString());
        this.mPhoneNumber.sendKeys(data.get("mPhoneNumber").toString());
    }
}
