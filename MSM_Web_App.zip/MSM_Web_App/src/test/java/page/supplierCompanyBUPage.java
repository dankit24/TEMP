package page;

public class supplierCompanyBUPage {
}
