package page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class loginPage {
    WebDriver driver;

    public loginPage(WebDriver driver) { this.driver = driver;}

    @FindBy(id = "mat-input-0") WebElement userNameField;
    @FindBy(id = "mat-input-1") WebElement passwordField;
    @FindBy(xpath = "/html/body/app-root/app-login/div/div[2]/form/div[3]/button") WebElement loginButton;

    public void validLoginTest(String userName, String password){
        this.userNameField.sendKeys(userName);
        this.passwordField.sendKeys(password);;
        this.loginButton.click();
    }
}
