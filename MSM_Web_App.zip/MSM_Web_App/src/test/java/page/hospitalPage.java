package page;

import com.github.javafaker.Faker;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class hospitalPage {
    WebDriver driver;
    Faker faker = new Faker();

    public hospitalPage(WebDriver driver){this.driver = driver;}

    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/app-sidebar/aside/div[3]/ul/li[2]/a") WebElement corpSetupTab;
    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/app-sidebar/aside/div[3]/ul/li[2]/ul/li[2]/a") WebElement hospitalSubTab;
    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/main/app-hospital-list/div/app-header/button[2]/span") WebElement addNewHospital;
    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/main/app-hospital-form/div/div/form/div[1]/div[1]/div/app-company-input/mat-form-field/div/div[1]/div") WebElement selectCompany;
    @FindBy(xpath = "/html/body/div[3]/div[2]/div/div/div/mat-option/span") WebElement selectedCompany;
    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/main/app-hospital-form/div/div/form/div[1]/div[1]/div/mat-form-field[1]/div/div[1]/div/input") WebElement insertHospitalID;
    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/main/app-hospital-form/div/div/form/div[1]/div[1]/div/mat-form-field[2]/div/div[1]/div/input") WebElement insertHospitalName;
    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/main/app-hospital-form/div/div/form/div[1]/div[1]/div/mat-form-field[3]/div/div[1]/div/mat-select/div/div[1]/span") WebElement selectHospitalType;
    @FindBy(xpath = "/html/body/div[3]/div[2]/div/div/div/mat-option[1]/span") WebElement selectedHospitalType;
    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/main/app-hospital-form/div/div/form/div[1]/div[1]/div/mat-form-field[4]/div/div[1]/div/input") WebElement hospitalTaxID;
    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/main/app-hospital-form/div/div/form/div[1]/div[2]/div/mat-form-field[1]/div/div[1]/div/input") WebElement insertEmail;
    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/main/app-hospital-form/div/div/form/div[1]/div[2]/div/mat-form-field[2]/div/div[1]/div/input") WebElement insertSocailMediaId;
    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/main/app-hospital-form/div/div/form/div[1]/div[2]/div/mat-form-field[3]/div/div[1]/div/input") WebElement insertWebsite;
    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/main/app-hospital-form/div/div/form/div[1]/div[3]/div/app-mailing-address/div/mat-form-field[1]/div/div[1]/div/input") WebElement insertAddLine1;
    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/main/app-hospital-form/div/div/form/div[1]/div[3]/div/app-mailing-address/div/mat-form-field[2]/div/div[1]/div/input") WebElement insertAddLine2;
    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/main/app-hospital-form/div/div/form/div[1]/div[3]/div/app-mailing-address/div/mat-form-field[3]/div/div[1]/div/input") WebElement insertAddLine3;
    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/main/app-hospital-form/div/div/form/div[1]/div[3]/div/app-mailing-address/div/mat-form-field[4]/div/div[1]/div/input") WebElement insertCity;
    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/main/app-hospital-form/div/div/form/div[1]/div[3]/div/app-mailing-address/div/mat-form-field[5]/div/div[1]/div/input") WebElement insertState;
    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/main/app-hospital-form/div/div/form/div[1]/div[3]/div/app-mailing-address/div/mat-form-field[6]/div/div[1]/div/input") WebElement insertCountry;
    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/main/app-hospital-form/div/div/form/div[1]/div[3]/div/app-mailing-address/div/mat-form-field[7]/div/div[1]/div/input") WebElement insertPostalCode;
    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/main/app-hospital-form/div/div/form/div[1]/div[3]/div/app-mailing-address/div/mat-form-field[8]/div/div[1]/div/input") WebElement insertPhoneNumber;

    public void addNewHospital(JSONObject data) throws InterruptedException {

        this.corpSetupTab.click();
        this.hospitalSubTab.click();
        this.addNewHospital.click();
        Thread.sleep(2000);
        this.selectCompany.click();
        Thread.sleep(2000);
        this.selectedCompany.click();
        Thread.sleep(2000);
        this.insertHospitalID.sendKeys(data.get("hospitalID").toString());
        this.insertHospitalName.sendKeys(data.get("hospitalName").toString());
        Thread.sleep(2000);
        this.selectHospitalType.click();
        Thread.sleep(2000);
        this.selectedHospitalType.click();
        Thread.sleep(2000);
        this.hospitalTaxID.sendKeys(data.get("hospitalTaxID").toString());
        this.insertEmail.sendKeys(data.get("email").toString());
        this.insertSocailMediaId.sendKeys(data.get("socialMediaID").toString());
        this.insertWebsite.sendKeys(data.get("website").toString());
        this.insertAddLine1.sendKeys(data.get("mAddressLine1").toString());
        this.insertAddLine2.sendKeys(data.get("mAddressLine2").toString());
        this.insertAddLine3.sendKeys(data.get("mAddressLine3").toString());
        this.insertCity.sendKeys(data.get("mCity").toString());
        this.insertState.sendKeys(data.get("mState").toString());
        this.insertCountry.sendKeys(data.get("mCountry").toString());
        this.insertPostalCode.sendKeys(data.get("mPostalCode").toString());
        this.insertPhoneNumber.sendKeys(data.get("mPhoneNumber").toString());
    }




}
