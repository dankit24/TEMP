package page;

import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class corpTeamPage {
    WebDriver driver;
    public corpTeamPage(WebDriver driver){this.driver=driver;}

    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/app-sidebar/aside/div[3]/ul/li[2]/a") WebElement corpSetupTab;
    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/app-sidebar/aside/div[3]/ul/li[2]/ul/li[3]/a") WebElement teamSubTab;
    @FindBy(xpath = "") WebElement companySelect;
    @FindBy(xpath = "") WebElement companySelected;
    @FindBy(xpath = "") WebElement hospitalSelect;
    @FindBy(xpath = "") WebElement hospitalSelected;
    @FindBy(xpath = "") WebElement teamID;
    @FindBy(xpath = "") WebElement teamName;
    @FindBy(xpath = "") WebElement description;
    @FindBy(xpath = "") WebElement notes;

    public void addNewTeam(JSONObject data) throws InterruptedException {
        /*System.out.println(dataArray);
        int arrayLength = dataArray.length();
        System.out.println(arrayLength);

        for(int i=0;i<arrayLength;i++){
            JSONObject data = (JSONObject) dataArray.get(i);*/
        this.corpSetupTab.click();
        this.teamSubTab.click();
        Thread.sleep(2000);
        this.companySelect.click();
        Thread.sleep(2000);
        this.companySelected.click();
        Thread.sleep(2000);
        this.hospitalSelect.click();
        Thread.sleep(2000);
        this.hospitalSelected.click();
        Thread.sleep(2000);
        this.teamID.sendKeys(data.get("teamID").toString());
        this.teamName.sendKeys(data.get("teamName").toString());
        this.description.sendKeys(data.get("description").toString());
        this.notes.sendKeys(data.get("notes").toString());
//    }
    }
}
