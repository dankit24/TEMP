package page;

import com.github.javafaker.Faker;
import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class corpHospitalPage {
    WebDriver driver;

    public corpHospitalPage(WebDriver driver){this.driver = driver;}

    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/app-sidebar/aside/div[3]/ul/li[2]") WebElement corpSetupTab;
    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/app-sidebar/aside/div[3]/ul/li[2]/ul/li[2]/a") WebElement hospitalSubTab;
    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/main/app-hospital-list/div/app-header/button[2]/span") WebElement addNewHospital;
    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/main/app-hospital-form/div/div/form/div[1]/div[1]/div/app-company-input/mat-form-field/div/div[1]/div") WebElement selectCompany;
    @FindBy(xpath = "/html/body/div[3]/div[2]/div/div/div/mat-option/span") WebElement selectedCompany;
    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/main/app-hospital-form/div/div/form/div[1]/div[1]/div/mat-form-field[1]/div/div[1]/div/input") WebElement hospitalID;
    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/main/app-hospital-form/div/div/form/div[1]/div[1]/div/mat-form-field[2]/div/div[1]/div/input") WebElement hospitalName;
    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/main/app-hospital-form/div/div/form/div[1]/div[1]/div/mat-form-field[3]/div/div[1]/div/mat-select/div/div[1]/span") WebElement selectHospitalType;
    @FindBy(xpath = "/html/body/div[3]/div[2]/div/div/div/mat-option[1]/span") WebElement selectedHospitalType;
    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/main/app-hospital-form/div/div/form/div[1]/div[1]/div/mat-form-field[4]/div/div[1]/div/input") WebElement hospitalTaxID;
    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/main/app-hospital-form/div/div/form/div[1]/div[2]/div/mat-form-field[1]/div/div[1]/div/input") WebElement email;
    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/main/app-hospital-form/div/div/form/div[1]/div[2]/div/mat-form-field[2]/div/div[1]/div/input") WebElement socialMediaID;
    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/main/app-hospital-form/div/div/form/div[1]/div[2]/div/mat-form-field[3]/div/div[1]/div/input") WebElement website;
    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/main/app-hospital-form/div/div/form/div[1]/div[3]/div/app-mailing-address/div/mat-form-field[1]/div/div[1]/div/input") WebElement mAddressLine1;
    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/main/app-hospital-form/div/div/form/div[1]/div[3]/div/app-mailing-address/div/mat-form-field[2]/div/div[1]/div/input") WebElement mAddressLine2;
    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/main/app-hospital-form/div/div/form/div[1]/div[3]/div/app-mailing-address/div/mat-form-field[3]/div/div[1]/div/input") WebElement mAddressLine3;
    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/main/app-hospital-form/div/div/form/div[1]/div[3]/div/app-mailing-address/div/mat-form-field[4]/div/div[1]/div/input") WebElement mCity;
    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/main/app-hospital-form/div/div/form/div[1]/div[3]/div/app-mailing-address/div/mat-form-field[5]/div/div[1]/div/input") WebElement mState;
    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/main/app-hospital-form/div/div/form/div[1]/div[3]/div/app-mailing-address/div/mat-form-field[6]/div/div[1]/div/input") WebElement mCountry;
    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/main/app-hospital-form/div/div/form/div[1]/div[3]/div/app-mailing-address/div/mat-form-field[7]/div/div[1]/div/input") WebElement mPostalCode;
    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/main/app-hospital-form/div/div/form/div[1]/div[3]/div/app-mailing-address/div/mat-form-field[8]/div/div[1]/div/input") WebElement mPhoneNumber;
    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/main/app-hospital-form/div/div/form/div[2]/button[1]") WebElement cancelButton;

    public void addNewHospital(JSONArray dataArray) throws InterruptedException {

        System.out.println(dataArray);
        int arrayLength = dataArray.length();
        System.out.println(arrayLength);

        for(int i=0;i<arrayLength;i++){
            JSONObject data = (JSONObject) dataArray.get(i);
            Thread.sleep(2000);
            this.corpSetupTab.click();
            this.hospitalSubTab.click();
            this.addNewHospital.click();
            Thread.sleep(2000);
            this.selectCompany.click();
            Thread.sleep(2000);
            this.selectedCompany.click();
            Thread.sleep(2000);
            this.hospitalID.sendKeys(data.get("hospitalID").toString());
            this.hospitalName.sendKeys(data.get("hospitalName").toString());
            Thread.sleep(2000);
            this.selectHospitalType.click();
            Thread.sleep(2000);
            this.selectedHospitalType.click();
            Thread.sleep(2000);
            this.hospitalTaxID.sendKeys(data.get("hospitalTaxID").toString());
            this.email.sendKeys(data.get("email").toString());
            this.socialMediaID.sendKeys(data.get("socialMediaID").toString());
            this.website.sendKeys(data.get("website").toString());
            this.mAddressLine1.sendKeys(data.get("mAddressLine1").toString());
            this.mAddressLine2.sendKeys(data.get("mAddressLine2").toString());
            this.mAddressLine3.sendKeys(data.get("mAddressLine3").toString());
            this.mCity.sendKeys(data.get("mCity").toString());
            this.mState.sendKeys(data.get("mState").toString());
            this.mCountry.sendKeys(data.get("mCountry").toString());
            this.mPostalCode.sendKeys(data.get("mPostalCode").toString());
            this.mPhoneNumber.sendKeys(data.get("mPhoneNumber").toString());
            this.cancelButton.click();
            Thread.sleep(2000);
        }


    }




}
