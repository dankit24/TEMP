package page;

public class clinicPage {
}
