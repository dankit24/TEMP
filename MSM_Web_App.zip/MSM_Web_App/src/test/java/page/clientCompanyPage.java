package page;

import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class clientCompanyPage {
    WebDriver driver;

    public clientCompanyPage(WebDriver driver) {
        this.driver = driver;
    }

    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/app-sidebar/aside/div[3]/ul/li[3]/a")
    WebElement customerAccountSetupTab;
    @FindBy(xpath = "/html/body/app-root/app-main-layout/div/app-sidebar/aside/div[3]/ul/li[3]/a/ul/li[1]/a")
    WebElement clientCompanySubTab;
    @FindBy(xpath = "")
    WebElement companyID;
    @FindBy(xpath = "")
    WebElement companyTaxID;
    @FindBy(xpath = "")
    WebElement companyName;
    @FindBy(xpath = "")
    WebElement marketeerSelect;
    @FindBy(xpath = "")
    WebElement marketeerSelected;
    @FindBy(xpath = "")
    WebElement corporationTypeSelect;
    @FindBy(xpath = "")
    WebElement corporationTypeSelected;
    @FindBy(xpath = "")
    WebElement notes;
    @FindBy(xpath = "")
    WebElement email;
    @FindBy(xpath = "")
    WebElement socialMediaID;
    @FindBy(xpath = "")
    WebElement website;
    @FindBy(xpath = "")
    WebElement mAddressLine1;
    @FindBy(xpath = "")
    WebElement mAddressLine2;
    @FindBy(xpath = "")
    WebElement mAddressLine3;
    @FindBy(xpath = "")
    WebElement mCity;
    @FindBy(xpath = "")
    WebElement mState;
    @FindBy(xpath = "")
    WebElement mCountry;
    @FindBy(xpath = "")
    WebElement mPostalCode;
    @FindBy(xpath = "")
    WebElement mPhoneNumber;
    @FindBy(xpath = "")
    WebElement bAddressLine1;
    @FindBy(xpath = "")
    WebElement bAddressLine2;
    @FindBy(xpath = "")
    WebElement bAddressLine3;
    @FindBy(xpath = "")
    WebElement bCity;
    @FindBy(xpath = "")
    WebElement bState;
    @FindBy(xpath = "")
    WebElement bCountry;
    @FindBy(xpath = "")
    WebElement bPostalCode;
    @FindBy(xpath = "")
    WebElement bPhoneNumber;

    public void addNewClientCompany(JSONObject data) throws InterruptedException {

        /*System.out.println(dataArray);
        int arrayLength = dataArray.length();
        System.out.println(arrayLength);

        for(int i=0;i<arrayLength;i++){
            JSONObject data = (JSONObject) dataArray.get(i);*/
        this.customerAccountSetupTab.click();
        this.clientCompanySubTab.click();
        this.companyID.sendKeys(data.get("companyID").toString());
        this.companyTaxID.sendKeys(data.get("companyTaxID").toString());
        this.companyName.sendKeys(data.get("companyName").toString());
        Thread.sleep(2000);
        this.marketeerSelect.click();
        Thread.sleep(2000);
        this.marketeerSelected.click();
        Thread.sleep(2000);
        this.corporationTypeSelect.click();
        Thread.sleep(2000);
        this.corporationTypeSelected.click();
        Thread.sleep(2000);
        this.notes.sendKeys(data.get("notes").toString());
        this.email.sendKeys(data.get("email").toString());
        this.socialMediaID.sendKeys(data.get("socialMediaID").toString());
        this.website.sendKeys(data.get("website").toString());
        this.mAddressLine1.sendKeys(data.get("mAddressLine1").toString());
        this.mAddressLine2.sendKeys(data.get("mAddressLine2").toString());
        this.mAddressLine3.sendKeys(data.get("mAddressLine3").toString());
        this.mCity.sendKeys(data.get("mCity").toString());
        this.mState.sendKeys(data.get("mState").toString());
        this.mCountry.sendKeys(data.get("mCountry").toString());
        this.mPostalCode.sendKeys(data.get("mPostalCode").toString());
        this.mPhoneNumber.sendKeys(data.get("mPhoneNumber").toString());
        this.bAddressLine1.sendKeys(data.get("bAddressLine1").toString());
        this.bAddressLine2.sendKeys(data.get("bAddressLine2").toString());
        this.bAddressLine3.sendKeys(data.get("bAddressLine3").toString());
        this.bCity.sendKeys(data.get("bCity").toString());
        this.bState.sendKeys(data.get("bState").toString());
        this.bCountry.sendKeys(data.get("bCountry").toString());
        this.bPostalCode.sendKeys(data.get("bPostalCode").toString());
        this.bPhoneNumber.sendKeys(data.get("bPhoneNumber").toString());
    }
//}
}
