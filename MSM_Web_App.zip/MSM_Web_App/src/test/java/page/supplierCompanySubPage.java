package page;

public class supplierCompanySubPage {
}
