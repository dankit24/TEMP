package test;

import base.*;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.json.JSONObject;
import page.*;
import page.navigationBar.*;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.io.IOException;

public class testCase extends testBase{
    navigationBar navigate = PageFactory.initElements(driver, navigationBar.class);

    @BeforeTest
    public void preTest(){
        getDriver();
    }
    @Test()
    public void invalidLoginTest(){
        loginPage page = PageFactory.initElements(driver, loginPage.class);
        /*page.testCase("adesai@bosleo.com","bosleo");*/
        System.out.println("invalid");
    }
    @Test(dependsOnMethods = "invalidLoginTest")
    public void validLoginTest(){
        loginPage page = PageFactory.initElements(driver, loginPage.class);
        page.validLoginTest("ypatel@bosleo.com","bosleo");
    }
    @Test(enabled = false,dependsOnMethods = "validLoginTest")
    public void validateNavigationSideBar() throws InterruptedException {
        navigationBar page = PageFactory.initElements(driver, navigationBar.class);
        page.naviagtionTest();
    }
    @Test(dependsOnMethods = "validLoginTest")
    public void openCompanyList(){
        companyPage page = PageFactory.initElements(driver, companyPage.class);
        page.allCompanyListTest();
    }
    @Test(dependsOnMethods = "openCompanyList")
    public void openHospitalList() throws InterruptedException, IOException, InvalidFormatException {
        JSONObject data = ExcelReader.getSheetData("hospital");
        hospitalPage page = PageFactory.initElements(driver,hospitalPage.class);
        page.addNewHospital(data);
    }
}
