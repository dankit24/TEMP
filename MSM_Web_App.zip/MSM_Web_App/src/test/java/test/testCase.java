package test;

import base.*;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.json.JSONArray;
import org.json.JSONObject;
import page.*;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.io.IOException;

public class testCase extends testBase{
    navigationBar navigate = PageFactory.initElements(driver, navigationBar.class);

    @BeforeTest
    public void preTest(){
        getDriver();
    }

    @Test()
    public void validLoginTest(){
        loginPage page = PageFactory.initElements(driver, loginPage.class);
        page.validLoginTest("ypatel@bosleo.com","bosleo");
    }
    @Test(enabled = false,dependsOnMethods = "validLoginTest")
    public void validateNavigationSideBar() throws InterruptedException {
        navigationBar page = PageFactory.initElements(driver, navigationBar.class);
        page.naviagtionTest();
    }
    @Test(enabled = false,dependsOnMethods = "validLoginTest")
    public void openCompanyList(){
        corpCompanyPage page = PageFactory.initElements(driver, corpCompanyPage.class);
        page.allCompanyListTest();
    }
//    @Test(dependsOnMethods = "openCompanyList")
    @Test()
    public void openHospitalList() throws InterruptedException, IOException, InvalidFormatException {
        JSONArray dataArray = ExcelReader.getSheetData("hospital");
        corpHospitalPage page = PageFactory.initElements(driver, corpHospitalPage.class);
        page.addNewHospital(dataArray);
    }
//    @Test(enabled = false, dependsOnMethods = "openHospitalList")
//    public void openTeamList() throws InterruptedException, IOException, InvalidFormatException {
//        JSONObject data = ExcelReader.getSheetData("team");
//        corpTeamPage page = PageFactory.initElements(driver, corpTeamPage.class);
//        page.addNewTeam(data);
//    }
//    @Test(enabled = false, dependsOnMethods = "openTeamList")
//    public void openClinicList() throws InterruptedException, IOException, InvalidFormatException {
//        JSONObject data = ExcelReader.getSheetData("clinic");
//        corpClinicPage page = PageFactory.initElements(driver, corpClinicPage.class);
//        page.addNewClinic(data);
//    }
//    @Test(enabled = false, dependsOnMethods = "openClinicList")
//    public void openClientCompanyList() throws InterruptedException, IOException, InvalidFormatException {
//        JSONObject data = ExcelReader.getSheetData("clientCompany");
//        clientCompanyPage page = PageFactory.initElements(driver, clientCompanyPage.class);
//        page.addNewClientCompany(data);
//    }
//    @Test(enabled = false, dependsOnMethods = "openClientCompanyList")
//    public void openClientSubsidiaryList() throws InterruptedException, IOException, InvalidFormatException {
//        JSONObject data = ExcelReader.getSheetData("clientSubsidiary");
//        clientCompanySubPage page = PageFactory.initElements(driver, clientCompanySubPage.class);
//        page.addNewClientSubsidiary(data);
//    }
//    @Test(enabled = false, dependsOnMethods = "openClientSubsidiaryList")
//    public void openClientBUList() throws InterruptedException, IOException, InvalidFormatException {
//        JSONObject data = ExcelReader.getSheetData("clientBusinessUnit");
//        clientCompanyBUPage page = PageFactory.initElements(driver, clientCompanyBUPage.class);
//        page.addNewClientBU(data);
//    }
//    @Test(enabled = false, dependsOnMethods = "openClientBUList")
//    public void openClientEmployeeList() throws InterruptedException, IOException, InvalidFormatException {
//        JSONObject data = ExcelReader.getSheetData("clientEmployee");
//        clientCompanyEmployeePage page = PageFactory.initElements(driver, clientCompanyEmployeePage.class);
//        page.addNewClientEmployee(data);
//    }
//    @Test(enabled = false, dependsOnMethods = "openClientEmployeeList")
//    public void openSupplierCompanyList() throws InterruptedException, IOException, InvalidFormatException {
//        JSONObject data = ExcelReader.getSheetData("supplierCompany");
//        supplerCompanyPage page = PageFactory.initElements(driver, supplerCompanyPage.class);
//        page.addNewSupplierCompany(data);
//    }
//    @Test(enabled = false, dependsOnMethods = "openSupplierCompanyList")
//    public void openSupplierSubsidiaryList() throws InterruptedException, IOException, InvalidFormatException {
//        JSONObject data = ExcelReader.getSheetData("supplierSubsidiary");
//        supplierCompanySubPage page = PageFactory.initElements(driver, supplierCompanySubPage.class);
//        page.addNewSupplierSubsidiary(data);
//    }
//    @Test(enabled = false, dependsOnMethods = "openSupplierSubsidiaryList")
//    public void openSupplierBUList() throws InterruptedException, IOException, InvalidFormatException {
//        JSONObject data = ExcelReader.getSheetData("supplierBusinessUnit");
//        supplierCompanyBUPage page = PageFactory.initElements(driver, supplierCompanyBUPage.class);
//        page.addNewSupplierBU(data);
//    }
}
