package base;

import io.github.bonigarcia.wdm.FirefoxDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

import java.util.concurrent.TimeUnit;


public class testBase {

    public static WebDriver driver = null;
    public static String baseURL = "http://msmfrontend-env.5ifvthzyym.us-west-2.elasticbeanstalk.com";

    public testBase(){
    }

    @BeforeSuite
    public void beforeSuite()
    {
        System.setProperty("headless", "false"); // You can set this property elsewhere
        String headless = System.getProperty("headless");

        FirefoxDriverManager.firefoxdriver().setup();

        if("true".equals(headless)) {
            FirefoxOptions firefoxOptions = new FirefoxOptions();
            firefoxOptions.addArguments("--headless");
            driver = new FirefoxDriver(firefoxOptions);
            driver.manage().window().maximize();
            driver.get(baseURL);
        }

        else {
            driver = new FirefoxDriver();
            driver.manage().window().maximize();
            driver.get(baseURL);
            driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
        }
    }

    @AfterSuite(enabled = false)
    public void afterSuite()
    {

        if(null != driver) {
            driver.quit();
        }
    }

    public WebDriver getDriver()
    {
        return driver;
    }

}
