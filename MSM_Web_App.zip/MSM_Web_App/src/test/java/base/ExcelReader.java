package base;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


public class ExcelReader {

    public static JSONArray getSheetData(String sheetName) throws IOException, InvalidFormatException {
        JSONArray dataArray = new JSONArray();
        JSONObject data=null;
        List<String> keys = new ArrayList<>();
        List<String> sheets = new ArrayList<>();
        int sheetNumber = 0;
        // Create a Workbook
        Workbook workbook = WorkbookFactory.create(new File("/home/qa/Documents/Book1.xlsx"));
        // use a for-each loop to retrieve all sheets
        for(Sheet sheet: workbook) {
            sheets.add(sheet.getSheetName());
            if(sheet.getSheetName().equals(sheetName)) sheetNumber = sheets.indexOf(sheetName);
        }
        // Getting the Sheet at index zero
        Sheet sheet = workbook.getSheetAt(sheetNumber);

        // Create a DataFormatter to format and get each cell's value as String
        DataFormatter dataFormatter = new DataFormatter();
        for (Row row: sheet) {
            data = new JSONObject();
            if(row.getRowNum() == sheet.getTopRow()) {
                for (Cell cell : row) {
                    String cellValue = dataFormatter.formatCellValue(cell);
                    keys.add(cellValue);
//                    System.out.print(cellValue + "\t");
                }
                continue;
            }
            else{
                int i=0;
                for (Cell cell : row) {
                    String cellValue = dataFormatter.formatCellValue(cell);
                    data.put(""+keys.get(i)+"",""+cellValue+"");
//                    System.out.print(cellValue + "\t");
                    i++;
                }
            }
                dataArray.put(data);
        }
        workbook.close();
        return dataArray;
    }
}
