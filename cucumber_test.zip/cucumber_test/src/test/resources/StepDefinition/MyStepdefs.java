package StepDefinition;

import io.cucumber.java.en.When;

public class MyStepdefs {
    @When("Enter the Username <username>and Password <password>")
    public void enterTheUsernameUsernameAndPasswordPassword() {
    }
}
