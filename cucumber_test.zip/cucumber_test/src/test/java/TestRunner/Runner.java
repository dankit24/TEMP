package TestRunner;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(features="C:/Users/Ankit/IdeaProjects/webApp/cucumber_test/src/test/java/Features",glue={"StepDefinition"})
public class Runner
{
    public Runner(){

}
}

