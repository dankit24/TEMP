# JmeterAPISample
Sample application for load testing by jmeter api java code instead of gui and generating the jmx and csv reports

Full description on this sample is explained in my blog <a href="http://uttesh.blogspot.in/2015/04/jmeter-load-testing-by-code-jmeter-api.html" target="_blank">http://uttesh.blogspot.in/2015/04/jmeter-load-testing-by-code-jmeter-api.html</a>
